# Port Pilot HTML5 - Game Development Project

## Overview

Port Pilot HTML5 is a complete recreation of a classic Flash harbor navigation game using modern web technologies. The game features ship navigation through busy harbors, precision docking mechanics, obstacle avoidance, and progressive difficulty levels. Players control a ship that must navigate through various hazards including rocks, buoys, and moving boats to successfully dock at designated ports.

The project uses Phaser 3 as the primary game engine, providing physics-based ship movement, collision detection, and smooth animations. The game maintains feature parity with the original Flash version while adding modern web capabilities like responsive design, touch controls, and cross-platform compatibility.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
The application uses a hybrid architecture combining modern React with Phaser 3 game engine:

- **React Application**: Serves as the main application shell with UI components and state management
- **Phaser 3 Game Engine**: Handles core game mechanics, physics, rendering, and audio
- **Scene-Based Game Structure**: Organized into distinct scenes (Boot, Preload, Menu, Play, GameOver) for clean separation of concerns
- **Component-Based UI**: Uses Radix UI primitives with shadcn/ui styling for consistent interface elements

### Game Engine Structure
- **Physics System**: Arcade physics for ship movement, collision detection, and object interactions
- **Asset Management**: Centralized loading and management of sprites, audio, and animations
- **Input Handling**: Multi-modal input system supporting keyboard, mouse, and touch controls
- **Audio System**: Separate background music and sound effects with volume controls and mute functionality

### Styling and UI System
- **TailwindCSS**: Utility-first CSS framework for rapid styling and responsive design
- **CSS Custom Properties**: Theme-based color system for consistent visual design
- **Responsive Design**: Automatic scaling and layout adaptation for different screen sizes
- **Modern Typography**: Google Fonts integration (Orbitron, Roboto) for enhanced visual appeal

### Build and Development Tools
- **Vite**: Fast development server and build tool with hot module replacement
- **TypeScript**: Type safety for better development experience and code reliability
- **ESBuild**: Fast JavaScript bundling for production builds
- **PostCSS**: CSS processing with autoprefixer for browser compatibility

### Game Logic Architecture
- **Modular Design**: Separate classes for Ship, Port, Obstacle, and management systems
- **Configuration Management**: Centralized game constants and settings in GameConfig
- **State Management**: Scene-based state transitions and game progression tracking
- **Event-Driven Architecture**: Input events trigger game actions and state changes

## External Dependencies

### Core Framework Dependencies
- **Phaser 3** (v3.70.0): HTML5 game framework for rendering, physics, and input handling
- **React** (v18+): UI framework for application shell and interface components
- **React Three Fiber**: 3D rendering capabilities (currently unused but available)
- **Vite**: Development server and build tooling

### UI and Styling
- **Radix UI**: Headless component library for accessibility and behavior
- **TailwindCSS**: Utility-first CSS framework for styling
- **Lucide React**: Icon library for UI elements
- **Class Variance Authority**: Component variant management

### Database and Backend (Minimal)
- **Drizzle ORM**: Database toolkit with PostgreSQL support
- **Neon Database**: Serverless PostgreSQL database service
- **Express.js**: Minimal server setup (currently basic structure)

### Development Tools
- **TypeScript**: Type checking and development experience
- **ESLint**: Code linting and formatting
- **PostCSS**: CSS processing and optimization

### Audio and Assets
- **Web Audio API**: Browser-native audio handling through Phaser
- **Canvas/WebGL**: Hardware-accelerated rendering via Phaser
- **Local Storage**: High score and game state persistence

The architecture prioritizes performance, maintainability, and cross-platform compatibility while preserving the classic gameplay experience of the original Flash game.