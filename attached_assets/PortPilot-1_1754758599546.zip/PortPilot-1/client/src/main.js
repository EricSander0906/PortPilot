import { GameConfig } from './game/utils/GameConfig.js';
import { Boot } from './game/Boot.js';
import { Preload } from './game/Preload.js';
import { Menu } from './game/Menu.js';
import { Play } from './game/Play.js';
import { GameOver } from './game/GameOver.js';

/**
 * Port Pilot HTML5 - Main Game Entry Point
 * Converted from Flash with full feature parity
 */

class PortPilotGame {
    constructor() {
        this.config = {
            type: Phaser.AUTO,
            width: GameConfig.GAME_WIDTH,
            height: GameConfig.GAME_HEIGHT,
            parent: 'game-container',
            backgroundColor: '#0066cc',
            scale: {
                mode: Phaser.Scale.FIT,
                autoCenter: Phaser.Scale.CENTER_BOTH,
                min: {
                    width: 400,
                    height: 300
                },
                max: {
                    width: 1200,
                    height: 900
                }
            },
            physics: {
                default: 'arcade',
                arcade: {
                    gravity: { y: 0 },
                    debug: false
                }
            },
            scene: [Boot, Preload, Menu, Play, GameOver],
            audio: {
                disableWebAudio: false
            }
        };
        
        this.init();
    }
    
    init() {
        // Hide loading screen once Phaser is ready
        document.addEventListener('DOMContentLoaded', () => {
            const loading = document.getElementById('loading');
            if (loading) {
                loading.style.display = 'none';
            }
        });
        
        // Create Phaser game instance
        this.game = new Phaser.Game(this.config);
        
        // Global game reference for debugging
        window.game = this.game;
        
        console.log('Port Pilot HTML5 initialized');
    }
}

// Start the game when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    new PortPilotGame();
});
