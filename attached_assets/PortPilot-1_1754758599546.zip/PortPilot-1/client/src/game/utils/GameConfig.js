/**
 * Game Configuration Constants
 * Maintains original Flash game dimensions and settings
 */
export const GameConfig = {
    // Game dimensions (matching original Flash stage)
    GAME_WIDTH: 800,
    GAME_HEIGHT: 600,
    
    // Physics settings
    SHIP_SPEED: 150,
    SHIP_ROTATION_SPEED: 200,
    SHIP_DRAG: 0.95,
    WATER_RESISTANCE: 0.98,
    
    // Boat physics for Port Pilot
    BOAT_SPEED: 50,
    BOAT_AUTO_SPEED: 30,
    
    // Collision settings
    COLLISION_PADDING: 5,
    PORT_DOCK_DISTANCE: 30,
    
    // Game mechanics
    MAX_LIVES: 3,
    POINTS_PER_DOCK: 100,
    TIME_BONUS_MULTIPLIER: 10,
    LEVEL_TIME_LIMIT: 60, // seconds
    
    // Audio settings
    MASTER_VOLUME: 0.7,
    SFX_VOLUME: 0.5,
    MUSIC_VOLUME: 0.3,
    
    // UI settings
    HUD_MARGIN: 20,
    FONT_FAMILY: 'Arial',
    FONT_SIZE_LARGE: 24,
    FONT_SIZE_MEDIUM: 18,
    FONT_SIZE_SMALL: 14,
    
    // Colors (matching Flash UI)
    COLOR_PRIMARY: '#ffffff',
    COLOR_SECONDARY: '#ffff00',
    COLOR_DANGER: '#ff3300',
    COLOR_SUCCESS: '#00ff33',
    COLOR_UI_BG: '#003366',
    
    // Input settings
    KEYBOARD_REPEAT_DELAY: 100,
    TOUCH_DEADZONE: 20,
    
    // Performance settings
    MAX_PARTICLES: 50,
    OBJECT_POOL_SIZE: 20,
    
    // Level progression
    LEVELS: [
        {
            id: 1,
            name: 'Training Waters',
            obstacles: 3,
            ports: 2,
            timeLimit: 90,
            windSpeed: 0
        },
        {
            id: 2,
            name: 'Busy Harbor',
            obstacles: 5,
            ports: 3,
            timeLimit: 75,
            windSpeed: 1
        },
        {
            id: 3,
            name: 'Stormy Seas',
            obstacles: 7,
            ports: 4,
            timeLimit: 60,
            windSpeed: 2
        }
    ]
};
