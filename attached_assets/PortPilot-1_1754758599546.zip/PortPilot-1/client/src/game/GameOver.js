import { GameConfig } from './utils/GameConfig.js';
import { AudioManager } from './managers/AudioManager.js';

/**
 * GameOver Scene - Show final score and options
 */
export class GameOver extends Phaser.Scene {
    constructor() {
        super({ key: 'GameOver' });
    }
    
    init(data) {
        this.gameOverMessage = data.message || 'Game Over';
        this.isVictory = data.isVictory || false;
    }
    
    create() {
        console.log('GameOver scene started');
        
        // Initialize audio
        this.audioManager = new AudioManager(this);
        
        this.createBackground();
        this.createGameOverDisplay();
        this.createScoreDisplay();
        this.createOptions();
        this.setupInput();
        
        // Fade in
        this.cameras.main.fadeIn(500, 0, 0, 0);
        
        // Play appropriate sound
        if (this.isVictory) {
            this.audioManager.playVictoryMusic();
        } else {
            this.audioManager.playGameOverSound();
        }
    }
    
    createBackground() {
        const centerX = GameConfig.GAME_WIDTH / 2;
        const centerY = GameConfig.GAME_HEIGHT / 2;
        
        // Background color based on victory/defeat
        const bgColor = this.isVictory ? 0x003300 : 0x330000;
        this.add.rectangle(centerX, centerY, GameConfig.GAME_WIDTH, GameConfig.GAME_HEIGHT, bgColor);
        
        // Animated background effect
        this.createBackgroundEffect();
    }
    
    createBackgroundEffect() {
        // Create floating particles
        this.particles = this.add.group();
        
        for (let i = 0; i < 20; i++) {
            const x = Phaser.Math.Between(0, GameConfig.GAME_WIDTH);
            const y = Phaser.Math.Between(0, GameConfig.GAME_HEIGHT);
            const size = Phaser.Math.Between(2, 6);
            
            const color = this.isVictory ? 0x00ff00 : 0xff0000;
            const particle = this.add.circle(x, y, size, color, 0.3);
            
            this.particles.add(particle);
            
            // Floating animation
            this.tweens.add({
                targets: particle,
                y: y + Phaser.Math.Between(-100, 100),
                x: x + Phaser.Math.Between(-50, 50),
                alpha: { from: 0.3, to: 0 },
                duration: Phaser.Math.Between(3000, 6000),
                repeat: -1,
                yoyo: true,
                ease: 'Sine.easeInOut'
            });
        }
    }
    
    createGameOverDisplay() {
        const centerX = GameConfig.GAME_WIDTH / 2;
        
        // Main title
        const titleColor = this.isVictory ? '#00ff00' : '#ff3333';
        const title = this.isVictory ? 'MISSION COMPLETE!' : 'GAME OVER';
        
        const titleText = this.add.text(centerX, 120, title, {
            fontSize: '48px',
            fill: titleColor,
            fontFamily: 'Arial',
            fontStyle: 'bold',
            stroke: '#000000',
            strokeThickness: 3
        }).setOrigin(0.5);
        
        // Game over message
        this.add.text(centerX, 180, this.gameOverMessage, {
            fontSize: '20px',
            fill: '#ffffff',
            fontFamily: 'Arial',
            align: 'center'
        }).setOrigin(0.5);
        
        // Animate title
        this.tweens.add({
            targets: titleText,
            scaleX: 1.1,
            scaleY: 1.1,
            duration: 1500,
            yoyo: true,
            repeat: -1,
            ease: 'Sine.easeInOut'
        });
    }
    
    createScoreDisplay() {
        const centerX = GameConfig.GAME_WIDTH / 2;
        const startY = 250;
        
        // Get final stats
        const finalScore = this.registry.get('score') || 0;
        const level = this.registry.get('level') || 1;
        const highScore = this.registry.get('highScore') || 0;
        
        // Check if new high score
        const isNewHighScore = finalScore > 0 && finalScore >= highScore;
        if (isNewHighScore) {
            this.saveHighScore(finalScore);
            this.registry.set('highScore', finalScore);
        }
        
        // Score panel background
        const panel = this.add.rectangle(centerX, startY + 60, 400, 160, 0x000033, 0.8);
        panel.setStrokeStyle(2, 0x0066cc);
        
        // Final score
        this.add.text(centerX, startY, 'FINAL SCORE', {
            fontSize: '18px',
            fill: '#ffff99',
            fontFamily: 'Arial',
            fontStyle: 'bold'
        }).setOrigin(0.5);
        
        const scoreText = this.add.text(centerX, startY + 25, finalScore.toLocaleString(), {
            fontSize: '32px',
            fill: '#ffffff',
            fontFamily: 'Arial',
            fontStyle: 'bold'
        }).setOrigin(0.5);
        
        // Level reached
        this.add.text(centerX, startY + 65, `Level Reached: ${level}`, {
            fontSize: '16px',
            fill: '#cccccc',
            fontFamily: 'Arial'
        }).setOrigin(0.5);
        
        // High score
        const highScoreColor = isNewHighScore ? '#00ff00' : '#ffff99';
        const highScoreLabel = isNewHighScore ? 'NEW HIGH SCORE!' : 'Best Score';
        
        this.add.text(centerX, startY + 90, highScoreLabel, {
            fontSize: '16px',
            fill: highScoreColor,
            fontFamily: 'Arial',
            fontStyle: isNewHighScore ? 'bold' : 'normal'
        }).setOrigin(0.5);
        
        this.add.text(centerX, startY + 110, highScore.toLocaleString(), {
            fontSize: '20px',
            fill: highScoreColor,
            fontFamily: 'Arial',
            fontStyle: 'bold'
        }).setOrigin(0.5);
        
        // New high score animation
        if (isNewHighScore) {
            this.tweens.add({
                targets: scoreText,
                scaleX: 1.2,
                scaleY: 1.2,
                tint: 0x00ff00,
                duration: 500,
                yoyo: true,
                repeat: 3,
                ease: 'Power2'
            });
            
            // Confetti effect
            this.createConfetti();
        }
    }
    
    createConfetti() {
        for (let i = 0; i < 30; i++) {
            const x = Phaser.Math.Between(100, GameConfig.GAME_WIDTH - 100);
            const y = -50;
            const colors = [0xff0000, 0x00ff00, 0x0000ff, 0xffff00, 0xff00ff, 0x00ffff];
            const color = colors[Math.floor(Math.random() * colors.length)];
            
            const confetti = this.add.rectangle(x, y, 8, 8, color);
            
            this.tweens.add({
                targets: confetti,
                y: GameConfig.GAME_HEIGHT + 50,
                x: x + Phaser.Math.Between(-100, 100),
                rotation: Phaser.Math.Between(0, Math.PI * 4),
                duration: Phaser.Math.Between(2000, 4000),
                ease: 'Power2',
                onComplete: () => confetti.destroy()
            });
        }
    }
    
    createOptions() {
        const centerX = GameConfig.GAME_WIDTH / 2;
        const startY = 450;
        const buttonSpacing = 70;
        
        // Play Again button
        this.createButton(centerX - buttonSpacing, startY, 'PLAY AGAIN', () => {
            this.playAgain();
        });
        
        // Main Menu button
        this.createButton(centerX + buttonSpacing, startY, 'MAIN MENU', () => {
            this.returnToMenu();
        });
        
        // Instructions
        this.add.text(centerX, startY + 60, 'Press SPACE to play again • ESC for menu', {
            fontSize: '14px',
            fill: '#cccccc',
            fontFamily: 'Arial',
            align: 'center'
        }).setOrigin(0.5);
    }
    
    createButton(x, y, text, callback) {
        // Button background
        const bg = this.add.rectangle(x, y, 120, 40, 0x003366);
        bg.setStrokeStyle(2, 0x0066cc);
        
        // Button text
        const buttonText = this.add.text(x, y, text, {
            fontSize: '14px',
            fill: '#ffffff',
            fontFamily: 'Arial',
            fontStyle: 'bold'
        }).setOrigin(0.5);
        
        // Make interactive
        bg.setInteractive({ useHandCursor: true });
        
        // Hover effects
        bg.on('pointerover', () => {
            bg.setFillStyle(0x0066cc);
            buttonText.setScale(1.1);
        });
        
        bg.on('pointerout', () => {
            bg.setFillStyle(0x003366);
            buttonText.setScale(1.0);
        });
        
        bg.on('pointerdown', () => {
            bg.setFillStyle(0x004488);
            buttonText.setScale(0.95);
        });
        
        bg.on('pointerup', () => {
            bg.setFillStyle(0x0066cc);
            buttonText.setScale(1.1);
            this.audioManager.playClickSound();
            callback();
        });
        
        return { bg, text: buttonText };
    }
    
    setupInput() {
        // Keyboard shortcuts
        this.input.keyboard.on('keydown-SPACE', () => {
            this.playAgain();
        });
        
        this.input.keyboard.on('keydown-ESC', () => {
            this.returnToMenu();
        });
        
        this.input.keyboard.on('keydown-ENTER', () => {
            this.playAgain();
        });
    }
    
    playAgain() {
        // Reset game state
        this.registry.set('score', 0);
        this.registry.set('lives', GameConfig.MAX_LIVES);
        this.registry.set('level', 1);
        
        this.cameras.main.fadeOut(500, 0, 0, 0);
        this.cameras.main.once('camerafadeoutcomplete', () => {
            this.scene.start('Play');
        });
    }
    
    returnToMenu() {
        this.cameras.main.fadeOut(500, 0, 0, 0);
        this.cameras.main.once('camerafadeoutcomplete', () => {
            this.scene.start('Menu');
        });
    }
    
    saveHighScore(score) {
        try {
            localStorage.setItem('portPilot_highScore', score.toString());
            console.log('High score saved:', score);
        } catch (e) {
            console.warn('Could not save high score:', e);
        }
    }
}
