import { GameConfig } from './utils/GameConfig.js';
import { Utils } from './utils/Utils.js';
import { Boat } from './objects/Boat.js';
import { Dock } from './objects/Dock.js';
import { Cloud } from './objects/Cloud.js';
import { AudioManager } from './managers/AudioManager.js';
import { InputManager } from './managers/InputManager.js';

/**
 * Play Scene - Main gameplay
 */
export class Play extends Phaser.Scene {
    constructor() {
        super({ key: 'Play' });
    }
    
    create() {
        console.log('Play scene started');
        
        this.initializeGame();
        this.createWorld();
        this.createGameObjects();
        this.createUI();
        this.setupMouseInput();
        
        // Fade in
        this.cameras.main.fadeIn(300, 0, 0, 0);
        
        console.log('Port Pilot initialized');
    }
    
    update(time, delta) {
        if (this.gameState !== 'playing') return;
        
        // Update game timer
        this.gameTime += delta;
        
        // Update boat spawning
        this.updateBoatSpawning(delta);
        
        // Update cloud spawning
        this.updateCloudSpawning(delta);
        
        // Update all boats
        this.boats.forEach((boat, index) => {
            const shouldRemove = boat.update(time, delta);
            if (shouldRemove) {
                this.boats.splice(index, 1);
            }
        });
        
        // Update all docks
        this.docks.forEach(dock => {
            dock.update(time, delta);
        });
        
        // Update clouds
        this.clouds.forEach((cloud, index) => {
            const shouldRemove = cloud.update(time, delta);
            if (shouldRemove) {
                this.clouds.splice(index, 1);
            }
        });
        
        // Check dock collisions
        this.checkDockCollisions();
        
        // Update UI
        this.updateUI();
    }
    
    initializeGame() {
        // Game state for Port Pilot
        this.gameState = 'playing';
        this.score = this.registry.get('score') || 0;
        this.deliveredCargo = 0;
        this.totalCargo = 0;
        
        // Timer (no time limit in Port Pilot, just for scoring)
        this.gameTime = 0;
        
        // Game objects arrays
        this.boats = [];
        this.docks = [];
        this.clouds = [];
        
        // Spawning timers
        this.boatSpawnTimer = 0;
        this.boatSpawnInterval = 3000; // 3 seconds between boat spawns
        this.cloudSpawnTimer = 0;
        this.cloudSpawnInterval = 8000; // 8 seconds between clouds
        
        // Managers
        this.audioManager = new AudioManager(this);
        
        console.log('Port Pilot initialized');
    }
    
    createWorld() {
        const centerX = GameConfig.GAME_WIDTH / 2;
        const centerY = GameConfig.GAME_HEIGHT / 2;
        
        // Water background
        this.add.rectangle(centerX, centerY, GameConfig.GAME_WIDTH, GameConfig.GAME_HEIGHT, 0x4488cc);
        
        // Create 6 colored docks at specified positions
        this.createDocks();
        
        // Create animated water pattern
        this.createWaterAnimation();
    }
    
    createDocks() {
        // Create 6 docks: 2 red, 2 yellow at top-left, middle-center, bottom-right
        const dockPositions = [
            // Top-left area
            { x: 150, y: 80, color: 'red', id: 1 },
            { x: 150, y: 180, color: 'yellow', id: 2 },
            
            // Middle-center area  
            { x: GameConfig.GAME_WIDTH / 2, y: GameConfig.GAME_HEIGHT / 2 - 50, color: 'red', id: 3 },
            { x: GameConfig.GAME_WIDTH / 2, y: GameConfig.GAME_HEIGHT / 2 + 50, color: 'yellow', id: 4 },
            
            // Bottom-right area
            { x: GameConfig.GAME_WIDTH - 150, y: GameConfig.GAME_HEIGHT - 180, color: 'red', id: 5 },
            { x: GameConfig.GAME_WIDTH - 150, y: GameConfig.GAME_HEIGHT - 80, color: 'yellow', id: 6 }
        ];
        
        dockPositions.forEach(pos => {
            const dock = new Dock(this, pos.x, pos.y, pos.color, pos.id);
            this.docks.push(dock);
        });
        
        console.log('Created 6 docks:', this.docks.length);
    }
    
    updateBoatSpawning(delta) {
        this.boatSpawnTimer += delta;
        
        if (this.boatSpawnTimer >= this.boatSpawnInterval) {
            this.spawnBoat();
            this.boatSpawnTimer = 0;
            
            // Vary spawn interval slightly
            this.boatSpawnInterval = 2500 + Math.random() * 2000;
        }
    }
    
    spawnBoat() {
        // Don't spawn too many boats at once
        if (this.boats.length >= 8) return;
        
        // Random spawn position from edges
        const spawnSide = Math.floor(Math.random() * 4);
        let spawnX, spawnY, hintX, hintY;
        
        switch (spawnSide) {
            case 0: // Top
                spawnX = Math.random() * GameConfig.GAME_WIDTH;
                spawnY = -30;
                hintX = spawnX;
                hintY = 20;
                break;
            case 1: // Right
                spawnX = GameConfig.GAME_WIDTH + 30;
                spawnY = Math.random() * GameConfig.GAME_HEIGHT;
                hintX = GameConfig.GAME_WIDTH - 20;
                hintY = spawnY;
                break;
            case 2: // Bottom
                spawnX = Math.random() * GameConfig.GAME_WIDTH;
                spawnY = GameConfig.GAME_HEIGHT + 30;
                hintX = spawnX;
                hintY = GameConfig.GAME_HEIGHT - 20;
                break;
            case 3: // Left
                spawnX = -30;
                spawnY = Math.random() * GameConfig.GAME_HEIGHT;
                hintX = 20;
                hintY = spawnY;
                break;
        }
        
        // Show emergence hint
        this.showBoatEmergenceHint(hintX, hintY);
        
        // Generate cargo configuration
        const cargoConfig = this.generateCargoConfig();
        
        // Create boat
        const boat = new Boat(this, spawnX, spawnY, cargoConfig);
        this.boats.push(boat);
        
        console.log('Boat spawned with cargo:', cargoConfig);
    }
    
    showBoatEmergenceHint(x, y) {
        // Create hint arrow pointing inward
        const hint = this.add.graphics();
        hint.fillStyle(0xffff00, 0.8);
        hint.fillTriangle(0, -10, -8, 5, 8, 5);
        hint.x = x;
        hint.y = y;
        
        // Pulse animation
        this.tweens.add({
            targets: hint,
            alpha: 0.3,
            scale: 1.3,
            duration: 800,
            yoyo: true,
            repeat: 2,
            onComplete: () => hint.destroy()
        });
        
        // Add text hint
        const hintText = this.add.text(x, y + 15, 'BOAT!', {
            fontSize: '12px',
            fill: '#ffff00',
            fontFamily: 'Arial',
            fontStyle: 'bold',
            stroke: '#000000',
            strokeThickness: 2
        }).setOrigin(0.5);
        
        this.tweens.add({
            targets: hintText,
            alpha: 0,
            y: y - 20,
            duration: 2000,
            onComplete: () => hintText.destroy()
        });
    }
    
    generateCargoConfig() {
        const configs = [
            ['red'],           // Single red cargo
            ['yellow'],        // Single yellow cargo  
            ['red', 'red', 'red'],      // 3 red cargo
            ['yellow', 'yellow', 'yellow'], // 3 yellow cargo
            ['red', 'yellow'],          // Mixed 2 cargo
            ['red', 'red', 'yellow'],   // Mixed 3 cargo
            ['yellow', 'yellow', 'red'], // Mixed 3 cargo
            ['red', 'yellow', 'red', 'yellow', 'yellow'] // 5 mixed cargo
        ];
        
        return configs[Math.floor(Math.random() * configs.length)];
    }
    
    updateCloudSpawning(delta) {
        this.cloudSpawnTimer += delta;
        
        if (this.cloudSpawnTimer >= this.cloudSpawnInterval) {
            this.spawnCloud();
            this.cloudSpawnTimer = 0;
            
            // Vary cloud spawn interval
            this.cloudSpawnInterval = 6000 + Math.random() * 8000;
        }
    }
    
    spawnCloud() {
        const cloud = Cloud.spawnCloud(this);
        this.clouds.push(cloud);
        console.log('Cloud spawned');
    }
    
    checkDockCollisions() {
        this.boats.forEach(boat => {
            this.docks.forEach(dock => {
                dock.checkBoatCollision(boat);
            });
        });
    }
    
    createWaterAnimation() {
        // Create subtle wave effect
        this.waterOverlay = this.add.graphics();
        
        this.tweens.addCounter({
            from: 0,
            to: Math.PI * 2,
            duration: 4000,
            repeat: -1,
            onUpdate: (tween) => {
                this.waterOverlay.clear();
                this.waterOverlay.fillStyle(0x0066aa, 0.1);
                
                for (let x = 0; x < GameConfig.GAME_WIDTH; x += 40) {
                    for (let y = 0; y < GameConfig.GAME_HEIGHT; y += 40) {
                        const wave = Math.sin(tween.getValue() + x * 0.01 + y * 0.01) * 10;
                        this.waterOverlay.fillCircle(x, y + wave, 15);
                    }
                }
            }
        });
    }
    
    createBoundaries() {
        // Visual boundary indicators
        const boundaryColor = 0x666666;
        const boundaryAlpha = 0.5;
        
        // Top and bottom boundaries
        this.add.rectangle(GameConfig.GAME_WIDTH / 2, 5, GameConfig.GAME_WIDTH, 10, boundaryColor, boundaryAlpha);
        this.add.rectangle(GameConfig.GAME_WIDTH / 2, GameConfig.GAME_HEIGHT - 5, GameConfig.GAME_WIDTH, 10, boundaryColor, boundaryAlpha);
        
        // Left and right boundaries
        this.add.rectangle(5, GameConfig.GAME_HEIGHT / 2, 10, GameConfig.GAME_HEIGHT, boundaryColor, boundaryAlpha);
        this.add.rectangle(GameConfig.GAME_WIDTH - 5, GameConfig.GAME_HEIGHT / 2, 10, GameConfig.GAME_HEIGHT, boundaryColor, boundaryAlpha);
    }
    
    createGameObjects() {
        // No need for old ship/port system - Port Pilot uses boats and docks
        console.log('Port Pilot game objects ready');
    }
    
    addScore(points) {
        this.score += points;
        this.deliveredCargo++;
        this.registry.set('score', this.score);
        
        // Visual score indicator
        this.showScoreGain(points);
    }
    
    showScoreGain(points) {
        const scoreText = this.add.text(GameConfig.GAME_WIDTH - 100, 50, `+${points}`, {
            fontSize: '20px',
            fill: '#ffff00',
            fontFamily: 'Arial',
            fontStyle: 'bold',
            stroke: '#000000',
            strokeThickness: 2
        });
        
        this.tweens.add({
            targets: scoreText,
            y: 20,
            alpha: 0,
            duration: 1500,
            onComplete: () => scoreText.destroy()
        });
    }
    
    setupMouseInput() {
        // Enable drag and drop for boats - this is handled by each Boat individually
        this.input.on('drag', (pointer, gameObject, dragX, dragY) => {
            // Handled by Boat class
        });
        
        console.log('Mouse input for boat dragging ready');
    }
    
    createUI() {
        // UI background panel
        this.uiPanel = this.add.rectangle(GameConfig.GAME_WIDTH / 2, 30, GameConfig.GAME_WIDTH - 20, 50, 0x000033, 0.8);
        this.uiPanel.setStrokeStyle(2, 0x0066cc);
        this.uiPanel.setScrollFactor(0);
        
        // Score
        this.scoreText = this.add.text(20, 15, `Score: ${this.score.toLocaleString()}`, {
            fontSize: '16px',
            fill: '#ffffff',
            fontFamily: 'Arial'
        }).setScrollFactor(0);
        
        // Boats counter
        this.boatsText = this.add.text(200, 15, `Boats: 0`, {
            fontSize: '16px',
            fill: '#66ccff',
            fontFamily: 'Arial'
        }).setScrollFactor(0);
        
        // Cargo delivered counter
        this.cargoText = this.add.text(350, 15, `Cargo: ${this.deliveredCargo}`, {
            fontSize: '16px',
            fill: '#66ff66',
            fontFamily: 'Arial'
        }).setScrollFactor(0);
        
        // Game time
        this.timeText = this.add.text(500, 15, `Time: 00:00`, {
            fontSize: '16px',
            fill: '#ffff66',
            fontFamily: 'Arial'
        }).setScrollFactor(0);
        
        // Instructions
        this.instructionText = this.add.text(GameConfig.GAME_WIDTH / 2, GameConfig.GAME_HEIGHT - 30, 
            'Drag boats to deliver red and yellow cargo to matching colored docks', {
            fontSize: '14px',
            fill: '#ffffff',
            fontFamily: 'Arial',
            stroke: '#000000',
            strokeThickness: 2,
            align: 'center'
        }).setOrigin(0.5).setScrollFactor(0);
        
        // Pause button
        this.pauseButton = this.add.text(GameConfig.GAME_WIDTH - 20, 15, 'PAUSE', {
            fontSize: '14px',
            fill: '#cccccc',
            fontFamily: 'Arial'
        }).setOrigin(1, 0).setScrollFactor(0).setInteractive({ useHandCursor: true });
        
        this.pauseButton.on('pointerdown', () => {
            this.togglePause();
        });
    }
    
    // Port Pilot doesn't need the old collision and input systems
    
    updateUI() {
        if (this.scoreText) this.scoreText.setText(`Score: ${this.score.toLocaleString()}`);
        if (this.boatsText) this.boatsText.setText(`Boats: ${this.boats.length}`);
        if (this.cargoText) this.cargoText.setText(`Cargo: ${this.deliveredCargo}`);
        if (this.timeText) {
            const minutes = Math.floor(this.gameTime / 60000);
            const seconds = Math.floor((this.gameTime % 60000) / 1000);
            this.timeText.setText(`Time: ${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`);
        }
    }
    
    handlePortDocking(port) {
        if (port.isDocked) return;
        
        // Check docking speed (must be slow enough)
        const shipSpeed = this.ship.body.velocity.length();
        const dockingSpeed = 50;
        
        if (shipSpeed > dockingSpeed) {
            // Too fast - bounce off
            this.audioManager.playCollisionSound();
            this.ship.takeDamage();
            return;
        }
        
        // Successful docking
        port.dock();
        this.dockedPorts++;
        
        // Calculate score
        let points = GameConfig.POINTS_PER_DOCK;
        
        // Perfect docking bonus
        if (shipSpeed < 20) {
            points *= 2;
            this.showFloatingText(port.x, port.y - 50, 'PERFECT!', '#00ff00');
        }
        
        this.addScore(points);
        this.audioManager.playDockSound();
        
        // Visual feedback
        this.showFloatingText(port.x, port.y - 30, `+${points}`, '#ffff00');
        this.createDockParticles(port.x, port.y);
        
        console.log(`Docked at port ${port.portNumber}, score: ${points}`);
    }
    
    handleObstacleCollision(obstacle) {
        console.log('Ship hit obstacle');
        
        this.ship.takeDamage();
        this.audioManager.playCollisionSound();
        
        // Push ship away from obstacle
        const angle = Utils.angleBetween(obstacle.x, obstacle.y, this.ship.x, this.ship.y);
        this.ship.body.setVelocity(
            Math.cos(angle) * 200,
            Math.sin(angle) * 200
        );
        
        // Visual feedback
        this.createCollisionParticles(this.ship.x, this.ship.y);
        this.showFloatingText(this.ship.x, this.ship.y - 40, '-DAMAGE-', '#ff0000');
        
        // Check if ship is destroyed
        if (this.ship.health <= 0) {
            this.shipDestroyed();
        }
    }
    
    shipDestroyed() {
        this.lives--;
        this.audioManager.playExplosionSound();
        
        if (this.lives <= 0) {
            this.gameOver('Ship destroyed!');
        } else {
            // Respawn ship
            this.respawnShip();
        }
    }
    
    respawnShip() {
        // Reset ship position and health
        this.ship.x = 100;
        this.ship.y = GameConfig.GAME_HEIGHT / 2;
        this.ship.setRotation(0);
        this.ship.body.setVelocity(0, 0);
        this.ship.health = this.ship.maxHealth;
        
        // Brief invincibility
        this.ship.setAlpha(0.5);
        this.tweens.add({
            targets: this.ship,
            alpha: 1,
            duration: 2000,
            ease: 'Power2'
        });
        
        this.showFloatingText(this.ship.x, this.ship.y - 50, 'RESPAWNED', '#00ffff');
    }
    
    addScore(points) {
        this.score += points;
        this.registry.set('score', this.score);
        
        // Check for high score
        const highScore = this.registry.get('highScore');
        if (this.score > highScore) {
            this.registry.set('highScore', this.score);
        }
    }
    
    showFloatingText(x, y, text, color = '#ffffff') {
        const floatingText = this.add.text(x, y, text, {
            fontSize: '16px',
            fill: color,
            fontFamily: 'Arial',
            fontStyle: 'bold'
        }).setOrigin(0.5);
        
        this.tweens.add({
            targets: floatingText,
            y: y - 50,
            alpha: 0,
            duration: 1500,
            ease: 'Power2',
            onComplete: () => {
                floatingText.destroy();
            }
        });
    }
    
    createDockParticles(x, y) {
        // Success particle burst
        for (let i = 0; i < 10; i++) {
            const particle = this.add.circle(x, y, 3, 0x00ff00);
            
            this.tweens.add({
                targets: particle,
                x: x + Phaser.Math.Between(-50, 50),
                y: y + Phaser.Math.Between(-50, 50),
                alpha: 0,
                scale: 0,
                duration: 1000,
                ease: 'Power2',
                onComplete: () => particle.destroy()
            });
        }
    }
    
    createCollisionParticles(x, y) {
        // Collision particle burst
        for (let i = 0; i < 8; i++) {
            const particle = this.add.circle(x, y, 4, 0xff0000);
            
            this.tweens.add({
                targets: particle,
                x: x + Phaser.Math.Between(-40, 40),
                y: y + Phaser.Math.Between(-40, 40),
                alpha: 0,
                duration: 800,
                ease: 'Power2',
                onComplete: () => particle.destroy()
            });
        }
    }
    
    checkWinCondition() {
        if (this.dockedPorts >= this.totalPorts) {
            this.levelComplete();
        }
    }
    
    levelComplete() {
        this.gameState = 'complete';
        
        // Calculate time bonus
        const timeBonus = Math.floor(this.timeRemaining * GameConfig.TIME_BONUS_MULTIPLIER);
        this.addScore(timeBonus);
        
        console.log(`Level ${this.currentLevel} complete! Time bonus: ${timeBonus}`);
        
        // Visual feedback
        this.showFloatingText(GameConfig.GAME_WIDTH / 2, GameConfig.GAME_HEIGHT / 2, 'LEVEL COMPLETE!', '#00ff00');
        this.audioManager.playSuccessSound();
        
        // Advance to next level or end game
        this.time.delayedCall(2000, () => {
            if (this.currentLevel < GameConfig.LEVELS.length) {
                this.nextLevel();
            } else {
                this.gameComplete();
            }
        });
    }
    
    nextLevel() {
        this.currentLevel++;
        this.registry.set('level', this.currentLevel);
        
        this.cameras.main.fadeOut(500, 0, 0, 0);
        this.cameras.main.once('camerafadeoutcomplete', () => {
            this.scene.restart();
        });
    }
    
    gameComplete() {
        console.log('All levels completed!');
        this.showFloatingText(GameConfig.GAME_WIDTH / 2, GameConfig.GAME_HEIGHT / 2 + 50, 'ALL LEVELS COMPLETE!', '#ffff00');
        
        this.time.delayedCall(3000, () => {
            this.scene.start('GameOver', { 
                message: 'Congratulations! You completed all levels!',
                isVictory: true 
            });
        });
    }
    
    gameOver(message) {
        this.gameState = 'gameover';
        console.log('Game over:', message);
        
        this.cameras.main.fadeOut(1000, 0, 0, 0);
        this.cameras.main.once('camerafadeoutcomplete', () => {
            this.scene.start('GameOver', { 
                message: message,
                isVictory: false 
            });
        });
    }
    
    togglePause() {
        if (this.gameState === 'playing') {
            this.gameState = 'paused';
            this.physics.pause();
            this.tweens.pauseAll();
            this.showPauseMenu();
        } else if (this.gameState === 'paused') {
            this.gameState = 'playing';
            this.physics.resume();
            this.tweens.resumeAll();
            this.hidePauseMenu();
        }
    }
    
    showPauseMenu() {
        this.pauseOverlay = this.add.rectangle(
            GameConfig.GAME_WIDTH / 2,
            GameConfig.GAME_HEIGHT / 2,
            GameConfig.GAME_WIDTH,
            GameConfig.GAME_HEIGHT,
            0x000000,
            0.7
        ).setScrollFactor(0);
        
        this.pauseText = this.add.text(
            GameConfig.GAME_WIDTH / 2,
            GameConfig.GAME_HEIGHT / 2,
            'PAUSED\n\nPress ESC or P to resume\nPress M to return to menu',
            {
                fontSize: '24px',
                fill: '#ffffff',
                fontFamily: 'Arial',
                align: 'center',
                lineSpacing: 10
            }
        ).setOrigin(0.5).setScrollFactor(0);
        
        // Menu key
        this.input.keyboard.once('keydown-M', () => {
            this.returnToMenu();
        });
    }
    
    hidePauseMenu() {
        if (this.pauseOverlay) {
            this.pauseOverlay.destroy();
            this.pauseText.destroy();
        }
    }
    
    returnToMenu() {
        this.scene.start('Menu');
    }
}
