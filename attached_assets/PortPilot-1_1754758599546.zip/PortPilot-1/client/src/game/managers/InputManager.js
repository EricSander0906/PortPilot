import { GameConfig } from '../utils/GameConfig.js';

/**
 * InputManager - Handles all game input (keyboard, mouse, touch)
 */
export class InputManager {
    constructor(scene) {
        this.scene = scene;
        this.keys = {};
        this.mouse = {};
        this.touch = {};
        
        this.setupKeyboard();
        this.setupMouse();
        this.setupTouch();
        
        console.log('InputManager initialized');
    }
    
    setupKeyboard() {
        // Create cursor keys
        this.cursors = this.scene.input.keyboard.createCursorKeys();
        
        // Create WASD keys
        this.wasd = this.scene.input.keyboard.addKeys('W,S,A,D');
        
        // Create additional control keys
        this.controlKeys = this.scene.input.keyboard.addKeys({
            space: Phaser.Input.Keyboard.KeyCodes.SPACE,
            enter: Phaser.Input.Keyboard.KeyCodes.ENTER,
            escape: Phaser.Input.Keyboard.KeyCodes.ESC,
            pause: Phaser.Input.Keyboard.KeyCodes.P,
            mute: Phaser.Input.Keyboard.KeyCodes.M
        });
        
        // Track key states
        this.keyStates = {
            up: false,
            down: false,
            left: false,
            right: false,
            space: false,
            enter: false,
            escape: false,
            pause: false,
            mute: false
        };
        
        // Key repeat prevention
        this.lastKeyTime = {};
        this.keyRepeatDelay = GameConfig.KEYBOARD_REPEAT_DELAY;
        
        console.log('Keyboard input setup complete');
    }
    
    setupMouse() {
        this.mouse = {
            x: 0,
            y: 0,
            isDown: false,
            justPressed: false,
            justReleased: false
        };
        
        // Mouse event listeners
        this.scene.input.on('pointermove', (pointer) => {
            this.mouse.x = pointer.x;
            this.mouse.y = pointer.y;
        });
        
        this.scene.input.on('pointerdown', (pointer) => {
            this.mouse.isDown = true;
            this.mouse.justPressed = true;
            this.mouse.x = pointer.x;
            this.mouse.y = pointer.y;
        });
        
        this.scene.input.on('pointerup', (pointer) => {
            this.mouse.isDown = false;
            this.mouse.justReleased = true;
            this.mouse.x = pointer.x;
            this.mouse.y = pointer.y;
        });
        
        console.log('Mouse input setup complete');
    }
    
    setupTouch() {
        // Touch controls for mobile
        this.touch = {
            isActive: false,
            startX: 0,
            startY: 0,
            currentX: 0,
            currentY: 0,
            deltaX: 0,
            deltaY: 0,
            deadZone: GameConfig.TOUCH_DEADZONE
        };
        
        // Check if device supports touch
        this.isTouchDevice = 'ontouchstart' in window || navigator.maxTouchPoints > 0;
        
        if (this.isTouchDevice) {
            this.setupTouchControls();
        }
        
        console.log('Touch input setup complete, touch device:', this.isTouchDevice);
    }
    
    setupTouchControls() {
        // Create virtual joystick for mobile
        this.createVirtualJoystick();
        
        // Touch event handlers
        this.scene.input.on('pointerdown', (pointer) => {
            if (pointer.isDown) {
                this.touch.isActive = true;
                this.touch.startX = pointer.x;
                this.touch.startY = pointer.y;
                this.touch.currentX = pointer.x;
                this.touch.currentY = pointer.y;
            }
        });
        
        this.scene.input.on('pointermove', (pointer) => {
            if (this.touch.isActive) {
                this.touch.currentX = pointer.x;
                this.touch.currentY = pointer.y;
                this.touch.deltaX = this.touch.currentX - this.touch.startX;
                this.touch.deltaY = this.touch.currentY - this.touch.startY;
                
                this.updateVirtualJoystick();
            }
        });
        
        this.scene.input.on('pointerup', () => {
            this.touch.isActive = false;
            this.touch.deltaX = 0;
            this.touch.deltaY = 0;
            this.hideVirtualJoystick();
        });
    }
    
    createVirtualJoystick() {
        // Only create on touch devices
        if (!this.isTouchDevice) return;
        
        // Joystick base (invisible initially)
        this.joystickBase = this.scene.add.circle(0, 0, 50, 0x333333, 0.3);
        this.joystickBase.setScrollFactor(0);
        this.joystickBase.setVisible(false);
        
        // Joystick knob
        this.joystickKnob = this.scene.add.circle(0, 0, 25, 0x666666, 0.7);
        this.joystickKnob.setScrollFactor(0);
        this.joystickKnob.setVisible(false);
        
        console.log('Virtual joystick created');
    }
    
    updateVirtualJoystick() {
        if (!this.joystickBase || !this.joystickKnob) return;
        
        // Show joystick
        this.joystickBase.setVisible(true);
        this.joystickKnob.setVisible(true);
        
        // Position base at touch start
        this.joystickBase.setPosition(this.touch.startX, this.touch.startY);
        
        // Calculate knob position with constraints
        const distance = Math.min(
            Math.sqrt(this.touch.deltaX ** 2 + this.touch.deltaY ** 2),
            45 // Max distance from center
        );
        
        if (distance > this.touch.deadZone) {
            const angle = Math.atan2(this.touch.deltaY, this.touch.deltaX);
            this.joystickKnob.setPosition(
                this.touch.startX + Math.cos(angle) * distance,
                this.touch.startY + Math.sin(angle) * distance
            );
        } else {
            this.joystickKnob.setPosition(this.touch.startX, this.touch.startY);
        }
    }
    
    hideVirtualJoystick() {
        if (this.joystickBase) this.joystickBase.setVisible(false);
        if (this.joystickKnob) this.joystickKnob.setVisible(false);
    }
    
    // Input state checking methods
    isUpPressed() {
        const keyboardUp = (this.cursors.up && this.cursors.up.isDown) || 
                          (this.wasd.W && this.wasd.W.isDown);
        const touchUp = this.touch.isActive && this.touch.deltaY < -this.touch.deadZone;
        
        return keyboardUp || touchUp;
    }
    
    isDownPressed() {
        const keyboardDown = (this.cursors.down && this.cursors.down.isDown) || 
                            (this.wasd.S && this.wasd.S.isDown);
        const touchDown = this.touch.isActive && this.touch.deltaY > this.touch.deadZone;
        
        return keyboardDown || touchDown;
    }
    
    isLeftPressed() {
        const keyboardLeft = (this.cursors.left && this.cursors.left.isDown) || 
                            (this.wasd.A && this.wasd.A.isDown);
        const touchLeft = this.touch.isActive && this.touch.deltaX < -this.touch.deadZone;
        
        return keyboardLeft || touchLeft;
    }
    
    isRightPressed() {
        const keyboardRight = (this.cursors.right && this.cursors.right.isDown) || 
                             (this.wasd.D && this.wasd.D.isDown);
        const touchRight = this.touch.isActive && this.touch.deltaX > this.touch.deadZone;
        
        return keyboardRight || touchRight;
    }
    
    isSpacePressed() {
        return this.controlKeys.space && this.controlKeys.space.isDown;
    }
    
    isEnterPressed() {
        return this.controlKeys.enter && this.controlKeys.enter.isDown;
    }
    
    isEscapePressed() {
        return this.controlKeys.escape && this.controlKeys.escape.isDown;
    }
    
    isPausePressed() {
        return this.controlKeys.pause && this.controlKeys.pause.isDown;
    }
    
    isMutePressed() {
        return this.controlKeys.mute && this.controlKeys.mute.isDown;
    }
    
    // Just pressed/released methods (for single-shot actions)
    wasUpJustPressed() {
        return this.wasKeyJustPressed('up', this.isUpPressed());
    }
    
    wasDownJustPressed() {
        return this.wasKeyJustPressed('down', this.isDownPressed());
    }
    
    wasLeftJustPressed() {
        return this.wasKeyJustPressed('left', this.isLeftPressed());
    }
    
    wasRightJustPressed() {
        return this.wasKeyJustPressed('right', this.isRightPressed());
    }
    
    wasSpaceJustPressed() {
        return this.wasKeyJustPressed('space', this.isSpacePressed());
    }
    
    wasEnterJustPressed() {
        return this.wasKeyJustPressed('enter', this.isEnterPressed());
    }
    
    wasEscapeJustPressed() {
        return this.wasKeyJustPressed('escape', this.isEscapePressed());
    }
    
    wasPauseJustPressed() {
        return this.wasKeyJustPressed('pause', this.isPausePressed());
    }
    
    wasMuteJustPressed() {
        return this.wasKeyJustPressed('mute', this.isMutePressed());
    }
    
    wasKeyJustPressed(keyName, isCurrentlyPressed) {
        const currentTime = this.scene.time.now;
        const wasPressed = this.keyStates[keyName];
        
        if (isCurrentlyPressed && !wasPressed) {
            // Key just pressed
            if (!this.lastKeyTime[keyName] || 
                currentTime - this.lastKeyTime[keyName] > this.keyRepeatDelay) {
                this.lastKeyTime[keyName] = currentTime;
                this.keyStates[keyName] = true;
                return true;
            }
        } else if (!isCurrentlyPressed && wasPressed) {
            // Key just released
            this.keyStates[keyName] = false;
        }
        
        return false;
    }
    
    // Mouse methods
    getMousePosition() {
        return { x: this.mouse.x, y: this.mouse.y };
    }
    
    isMouseDown() {
        return this.mouse.isDown;
    }
    
    wasMouseJustPressed() {
        const justPressed = this.mouse.justPressed;
        this.mouse.justPressed = false; // Reset flag
        return justPressed;
    }
    
    wasMouseJustReleased() {
        const justReleased = this.mouse.justReleased;
        this.mouse.justReleased = false; // Reset flag
        return justReleased;
    }
    
    // Touch methods
    getTouchDelta() {
        return {
            x: this.touch.deltaX,
            y: this.touch.deltaY
        };
    }
    
    getTouchDistance() {
        return Math.sqrt(this.touch.deltaX ** 2 + this.touch.deltaY ** 2);
    }
    
    getTouchAngle() {
        return Math.atan2(this.touch.deltaY, this.touch.deltaX);
    }
    
    isTouchActive() {
        return this.touch.isActive;
    }
    
    // Input strength (for analog-like controls)
    getHorizontalAxis() {
        let axis = 0;
        
        if (this.isLeftPressed()) axis -= 1;
        if (this.isRightPressed()) axis += 1;
        
        // Add touch analog input
        if (this.touch.isActive && Math.abs(this.touch.deltaX) > this.touch.deadZone) {
            const touchAxis = Math.max(-1, Math.min(1, this.touch.deltaX / 50));
            axis = touchAxis;
        }
        
        return axis;
    }
    
    getVerticalAxis() {
        let axis = 0;
        
        if (this.isUpPressed()) axis -= 1;
        if (this.isDownPressed()) axis += 1;
        
        // Add touch analog input
        if (this.touch.isActive && Math.abs(this.touch.deltaY) > this.touch.deadZone) {
            const touchAxis = Math.max(-1, Math.min(1, this.touch.deltaY / 50));
            axis = touchAxis;
        }
        
        return axis;
    }
    
    // Utility methods
    update() {
        // Update input states each frame
        // This can be called from the scene's update method if needed
        
        // Reset mouse flags
        this.mouse.justPressed = false;
        this.mouse.justReleased = false;
    }
    
    destroy() {
        // Clean up input handlers
        if (this.joystickBase) this.joystickBase.destroy();
        if (this.joystickKnob) this.joystickKnob.destroy();
        
        // Remove event listeners
        this.scene.input.off('pointermove');
        this.scene.input.off('pointerdown');
        this.scene.input.off('pointerup');
        
        console.log('InputManager destroyed');
    }
}
