import { GameConfig } from '../utils/GameConfig.js';

/**
 * AudioManager - Handles all game audio
 */
export class AudioManager {
    constructor(scene) {
        this.scene = scene;
        this.sounds = {};
        this.music = null;
        this.isMuted = false;
        this.musicVolume = GameConfig.MUSIC_VOLUME;
        this.sfxVolume = GameConfig.SFX_VOLUME;
        
        this.initializeAudio();
        console.log('AudioManager initialized');
    }
    
    initializeAudio() {
        try {
            // Load and setup music
            this.setupMusic();
            
            // Load and setup sound effects
            this.setupSoundEffects();
            
            // Load mute state from storage
            this.loadMuteState();
            
        } catch (error) {
            console.warn('Error initializing audio:', error);
        }
    }
    
    setupMusic() {
        // Background music (using existing audio file)
        if (this.scene.sound.get('background_music')) {
            this.music = this.scene.sound.get('background_music');
        } else {
            this.music = this.scene.sound.add('background_music', {
                volume: this.musicVolume,
                loop: true
            });
        }
    }
    
    setupSoundEffects() {
        // Hit/collision sound
        this.sounds.hit = this.scene.sound.add('hit_sound', {
            volume: this.sfxVolume
        });
        
        // Success/dock sound
        this.sounds.success = this.scene.sound.add('success_sound', {
            volume: this.sfxVolume
        });
        
        // Engine sound (modified background music with different settings)
        this.sounds.engine = this.scene.sound.add('engine_sound', {
            volume: this.sfxVolume * 0.3,
            loop: true,
            rate: 1.5 // Higher pitch for engine effect
        });
        
        // Click sound (using hit sound with different settings)
        this.sounds.click = this.scene.sound.add('collision_sound', {
            volume: this.sfxVolume * 0.5,
            rate: 2.0 // Higher pitch for UI click
        });
        
        // Dock sound
        this.sounds.dock = this.scene.sound.add('dock_sound', {
            volume: this.sfxVolume
        });
        
        console.log('Sound effects loaded:', Object.keys(this.sounds));
    }
    
    // Music controls
    playBackgroundMusic() {
        if (this.music && !this.isMuted) {
            try {
                if (!this.music.isPlaying) {
                    this.music.play();
                    console.log('Background music started');
                }
            } catch (error) {
                console.warn('Could not play background music:', error);
            }
        }
    }
    
    stopBackgroundMusic() {
        if (this.music && this.music.isPlaying) {
            this.music.stop();
            console.log('Background music stopped');
        }
    }
    
    pauseBackgroundMusic() {
        if (this.music && this.music.isPlaying) {
            this.music.pause();
        }
    }
    
    resumeBackgroundMusic() {
        if (this.music && this.music.isPaused) {
            this.music.resume();
        }
    }
    
    // Sound effect controls
    playHitSound() {
        this.playSound('hit');
    }
    
    playSuccessSound() {
        this.playSound('success');
    }
    
    playCollisionSound() {
        this.playSound('hit');
    }
    
    playDockSound() {
        this.playSound('dock');
    }
    
    playClickSound() {
        this.playSound('click');
    }
    
    playHoverSound() {
        // Subtle hover sound using hit sound at very low volume
        if (this.sounds.hit && !this.isMuted) {
            try {
                const hoverSound = this.scene.sound.add('hit_sound', {
                    volume: this.sfxVolume * 0.1,
                    rate: 3.0
                });
                hoverSound.play();
                hoverSound.once('complete', () => {
                    hoverSound.destroy();
                });
            } catch (error) {
                console.warn('Could not play hover sound:', error);
            }
        }
    }
    
    playEngineSound() {
        if (this.sounds.engine && !this.isMuted && !this.sounds.engine.isPlaying) {
            try {
                this.sounds.engine.play();
            } catch (error) {
                console.warn('Could not play engine sound:', error);
            }
        }
    }
    
    stopEngineSound() {
        if (this.sounds.engine && this.sounds.engine.isPlaying) {
            this.sounds.engine.stop();
        }
    }
    
    playExplosionSound() {
        // Use hit sound with lower pitch for explosion effect
        if (this.sounds.hit && !this.isMuted) {
            try {
                const explosionSound = this.scene.sound.add('hit_sound', {
                    volume: this.sfxVolume * 1.5,
                    rate: 0.5 // Lower pitch
                });
                explosionSound.play();
                explosionSound.once('complete', () => {
                    explosionSound.destroy();
                });
            } catch (error) {
                console.warn('Could not play explosion sound:', error);
            }
        }
    }
    
    playVictoryMusic() {
        // Use success sound looped for victory
        if (this.sounds.success && !this.isMuted) {
            try {
                this.stopBackgroundMusic();
                const victoryMusic = this.scene.sound.add('success_sound', {
                    volume: this.musicVolume * 1.2,
                    loop: true,
                    rate: 0.8 // Slower for more majestic feel
                });
                victoryMusic.play();
                
                // Stop after 5 seconds
                this.scene.time.delayedCall(5000, () => {
                    victoryMusic.stop();
                    victoryMusic.destroy();
                });
            } catch (error) {
                console.warn('Could not play victory music:', error);
            }
        }
    }
    
    playGameOverSound() {
        // Use hit sound with lower pitch for game over
        if (this.sounds.hit && !this.isMuted) {
            try {
                this.stopBackgroundMusic();
                const gameOverSound = this.scene.sound.add('hit_sound', {
                    volume: this.sfxVolume * 1.2,
                    rate: 0.3 // Much lower pitch for dramatic effect
                });
                gameOverSound.play();
                gameOverSound.once('complete', () => {
                    gameOverSound.destroy();
                });
            } catch (error) {
                console.warn('Could not play game over sound:', error);
            }
        }
    }
    
    // Generic sound playing method
    playSound(soundKey) {
        if (this.sounds[soundKey] && !this.isMuted) {
            try {
                // Clone the sound to allow overlapping
                const sound = this.scene.sound.add(this.sounds[soundKey].key, {
                    volume: this.sounds[soundKey].volume
                });
                sound.play();
                sound.once('complete', () => {
                    sound.destroy();
                });
            } catch (error) {
                console.warn(`Could not play sound ${soundKey}:`, error);
            }
        }
    }
    
    // Volume controls
    setMusicVolume(volume) {
        this.musicVolume = Math.max(0, Math.min(1, volume));
        if (this.music) {
            this.music.setVolume(this.musicVolume);
        }
    }
    
    setSFXVolume(volume) {
        this.sfxVolume = Math.max(0, Math.min(1, volume));
        Object.values(this.sounds).forEach(sound => {
            if (sound.setVolume) {
                sound.setVolume(this.sfxVolume);
            }
        });
    }
    
    setMasterVolume(volume) {
        const masterVol = Math.max(0, Math.min(1, volume));
        this.setMusicVolume(this.musicVolume * masterVol);
        this.setSFXVolume(this.sfxVolume * masterVol);
    }
    
    // Mute controls
    toggleMute() {
        this.isMuted = !this.isMuted;
        
        if (this.isMuted) {
            this.stopBackgroundMusic();
            this.stopEngineSound();
        } else {
            this.playBackgroundMusic();
        }
        
        this.saveMuteState();
        console.log(`Audio ${this.isMuted ? 'muted' : 'unmuted'}`);
        
        return this.isMuted;
    }
    
    mute() {
        if (!this.isMuted) {
            this.toggleMute();
        }
    }
    
    unmute() {
        if (this.isMuted) {
            this.toggleMute();
        }
    }
    
    // Persistence
    saveMuteState() {
        try {
            localStorage.setItem('portPilot_audioMuted', this.isMuted.toString());
        } catch (error) {
            console.warn('Could not save mute state:', error);
        }
    }
    
    loadMuteState() {
        try {
            const saved = localStorage.getItem('portPilot_audioMuted');
            if (saved !== null) {
                this.isMuted = saved === 'true';
                console.log('Loaded mute state:', this.isMuted);
            }
        } catch (error) {
            console.warn('Could not load mute state:', error);
            this.isMuted = false; // Default to unmuted
        }
    }
    
    // Cleanup
    destroy() {
        this.stopBackgroundMusic();
        this.stopEngineSound();
        
        // Clean up all sounds
        Object.values(this.sounds).forEach(sound => {
            if (sound.destroy) {
                sound.destroy();
            }
        });
        
        if (this.music && this.music.destroy) {
            this.music.destroy();
        }
        
        console.log('AudioManager destroyed');
    }
}
