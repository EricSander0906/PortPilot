import { GameConfig } from '../utils/GameConfig.js';
import { Utils } from '../utils/Utils.js';

/**
 * Obstacle class - Hazards to avoid in the harbor
 */
export class Obstacle extends Phaser.Physics.Arcade.Sprite {
    constructor(scene, x, y, type = 'rock') {
        super(scene, x, y, null);
        
        scene.add.existing(this);
        scene.physics.add.existing(this);
        
        this.scene = scene;
        this.obstacleType = type;
        
        this.initializeObstacle();
        this.createVisuals();
        this.setupPhysics();
        
        console.log(`${type} obstacle created at`, x, y);
    }
    
    initializeObstacle() {
        // Obstacle properties based on type
        switch (this.obstacleType) {
            case 'rock':
                this.width = 30;
                this.height = 30;
                this.color = 0x666666;
                this.isMoving = false;
                break;
            case 'buoy':
                this.width = 20;
                this.height = 20;
                this.color = 0xff3300;
                this.isMoving = true;
                this.bobSpeed = 0.002;
                this.bobDirection = 1;
                this.currentBob = 0;
                break;
            case 'boat':
                this.width = 40;
                this.height = 20;
                this.color = 0x994400;
                this.isMoving = true;
                this.moveSpeed = 30;
                this.moveDirection = Phaser.Math.Between(0, 360) * Math.PI / 180;
                break;
            default:
                this.width = 25;
                this.height = 25;
                this.color = 0x888888;
                this.isMoving = false;
        }
        
        // Common properties
        this.health = 100;
        this.isDestructible = this.obstacleType === 'buoy';
        this.originalX = this.x;
        this.originalY = this.y;
    }
    
    setupPhysics() {
        // Set collision body
        this.setSize(this.width - 4, this.height - 4);
        this.body.setImmovable(true);
        
        // Set mass based on type
        switch (this.obstacleType) {
            case 'rock':
                this.body.setMass(10);
                break;
            case 'buoy':
                this.body.setMass(1);
                break;
            case 'boat':
                this.body.setMass(5);
                break;
        }
    }
    
    createVisuals() {
        // Create obstacle graphics
        this.obstacleGraphics = this.scene.add.graphics();
        this.updateObstacleGraphics();
        
        // Create warning indicators for moving obstacles
        if (this.isMoving) {
            this.createWarningIndicator();
        }
        
        // Add environmental details
        this.addEnvironmentalDetails();
    }
    
    updateObstacleGraphics() {
        this.obstacleGraphics.clear();
        
        switch (this.obstacleType) {
            case 'rock':
                this.drawRock();
                break;
            case 'buoy':
                this.drawBuoy();
                break;
            case 'boat':
                this.drawBoat();
                break;
            default:
                this.drawGeneric();
        }
    }
    
    drawRock() {
        // Irregular rock shape
        this.obstacleGraphics.fillStyle(this.color);
        this.obstacleGraphics.beginPath();
        
        const points = [];
        const numPoints = 8;
        const baseRadius = this.width / 2;
        
        for (let i = 0; i < numPoints; i++) {
            const angle = (i / numPoints) * Math.PI * 2;
            const radius = baseRadius + Phaser.Math.Between(-5, 5);
            points.push({
                x: this.x + Math.cos(angle) * radius,
                y: this.y + Math.sin(angle) * radius
            });
        }
        
        this.obstacleGraphics.moveTo(points[0].x, points[0].y);
        for (let i = 1; i < points.length; i++) {
            this.obstacleGraphics.lineTo(points[i].x, points[i].y);
        }
        this.obstacleGraphics.closePath();
        this.obstacleGraphics.fillPath();
        
        // Rock outline
        this.obstacleGraphics.lineStyle(2, 0x333333);
        this.obstacleGraphics.strokePath();
        
        // Rock details (cracks/texture)
        this.obstacleGraphics.lineStyle(1, 0x444444, 0.7);
        this.obstacleGraphics.lineBetween(
            this.x - 8, this.y - 5,
            this.x + 6, this.y + 8
        );
        this.obstacleGraphics.lineBetween(
            this.x - 5, this.y + 10,
            this.x + 10, this.y - 3
        );
    }
    
    drawBuoy() {
        const bobOffset = Math.sin(this.currentBob) * 3;
        const currentY = this.y + bobOffset;
        
        // Buoy body
        this.obstacleGraphics.fillStyle(this.color);
        this.obstacleGraphics.fillEllipse(this.x, currentY, this.width, this.height);
        
        // Buoy stripes
        this.obstacleGraphics.fillStyle(0xffffff);
        this.obstacleGraphics.fillRect(this.x - this.width/2, currentY - 3, this.width, 6);
        
        // Buoy outline
        this.obstacleGraphics.lineStyle(2, 0xcc0000);
        this.obstacleGraphics.strokeEllipse(this.x, currentY, this.width, this.height);
        
        // Top marker light
        this.obstacleGraphics.fillStyle(0xffff00);
        this.obstacleGraphics.fillCircle(this.x, currentY - this.height/2 - 5, 3);
        
        // Chain/anchor line
        this.obstacleGraphics.lineStyle(1, 0x333333, 0.5);
        this.obstacleGraphics.lineBetween(this.x, currentY + this.height/2, this.x, this.y + 30);
    }
    
    drawBoat() {
        // Boat hull
        this.obstacleGraphics.fillStyle(this.color);
        this.obstacleGraphics.fillEllipse(this.x, this.y, this.width, this.height);
        
        // Boat cabin
        this.obstacleGraphics.fillStyle(0x663300);
        this.obstacleGraphics.fillRect(this.x - 8, this.y - 8, 16, 12);
        
        // Boat outline
        this.obstacleGraphics.lineStyle(2, 0x553300);
        this.obstacleGraphics.strokeEllipse(this.x, this.y, this.width, this.height);
        
        // Mast
        this.obstacleGraphics.lineStyle(3, 0x8B4513);
        this.obstacleGraphics.lineBetween(this.x, this.y - 10, this.x, this.y - 25);
        
        // Flag
        this.obstacleGraphics.fillStyle(0x0000ff);
        this.obstacleGraphics.fillTriangle(
            this.x, this.y - 25,
            this.x + 12, this.y - 20,
            this.x, this.y - 15
        );
    }
    
    drawGeneric() {
        // Generic obstacle
        this.obstacleGraphics.fillStyle(this.color);
        this.obstacleGraphics.fillRect(
            this.x - this.width/2,
            this.y - this.height/2,
            this.width,
            this.height
        );
        
        this.obstacleGraphics.lineStyle(2, 0x555555);
        this.obstacleGraphics.strokeRect(
            this.x - this.width/2,
            this.y - this.height/2,
            this.width,
            this.height
        );
    }
    
    createWarningIndicator() {
        if (this.obstacleType === 'boat') {
            // Navigation lights for boats
            this.leftLight = this.scene.add.circle(this.x - 15, this.y, 2, 0xff0000, 0.8);
            this.rightLight = this.scene.add.circle(this.x + 15, this.y, 2, 0x00ff00, 0.8);
            
            // Animate navigation lights
            this.scene.tweens.add({
                targets: [this.leftLight, this.rightLight],
                alpha: 0.3,
                duration: 1000,
                yoyo: true,
                repeat: -1,
                ease: 'Sine.easeInOut'
            });
        }
    }
    
    addEnvironmentalDetails() {
        // Add water ripples around obstacles
        if (this.obstacleType === 'rock' || this.obstacleType === 'buoy') {
            this.ripples = this.scene.add.group();
            
            for (let i = 0; i < 3; i++) {
                const ripple = this.scene.add.circle(
                    this.x, this.y,
                    20 + (i * 10),
                    0x004488,
                    0.1
                );
                ripple.setStrokeStyle(1, 0x0066cc, 0.3);
                this.ripples.add(ripple);
                
                // Animate ripples
                this.scene.tweens.add({
                    targets: ripple,
                    scaleX: 1.5,
                    scaleY: 1.5,
                    alpha: 0,
                    duration: 2000 + (i * 500),
                    repeat: -1,
                    ease: 'Power2.easeOut',
                    delay: i * 300
                });
            }
        }
    }
    
    update(time, delta) {
        this.updateMovement(delta);
        this.updateVisuals(delta);
        this.updateObstacleGraphics();
    }
    
    updateMovement(delta) {
        switch (this.obstacleType) {
            case 'buoy':
                // Bobbing motion
                this.currentBob += this.bobDirection * this.bobSpeed * delta;
                if (this.currentBob >= Math.PI) {
                    this.currentBob = Math.PI;
                    this.bobDirection = -1;
                } else if (this.currentBob <= 0) {
                    this.currentBob = 0;
                    this.bobDirection = 1;
                }
                break;
                
            case 'boat':
                // Slow patrol movement
                const moveX = Math.cos(this.moveDirection) * this.moveSpeed * (delta / 1000);
                const moveY = Math.sin(this.moveDirection) * this.moveSpeed * (delta / 1000);
                
                this.x += moveX;
                this.y += moveY;
                
                // Bounce off screen edges
                if (this.x <= 50 || this.x >= GameConfig.GAME_WIDTH - 50) {
                    this.moveDirection = Math.PI - this.moveDirection;
                }
                if (this.y <= 50 || this.y >= GameConfig.GAME_HEIGHT - 50) {
                    this.moveDirection = -this.moveDirection;
                }
                
                // Update navigation lights position
                if (this.leftLight && this.rightLight) {
                    this.leftLight.x = this.x - 15;
                    this.leftLight.y = this.y;
                    this.rightLight.x = this.x + 15;
                    this.rightLight.y = this.y;
                }
                
                // Update physics body position
                this.body.x = this.x - this.width/2;
                this.body.y = this.y - this.height/2;
                break;
        }
    }
    
    updateVisuals(delta) {
        // Update any visual effects specific to obstacle type
        if (this.obstacleType === 'rock') {
            // Occasionally spawn debris particles
            if (Math.random() < 0.005) {
                this.createDebrisParticle();
            }
        }
    }
    
    createDebrisParticle() {
        const debris = this.scene.add.circle(
            this.x + Phaser.Math.Between(-15, 15),
            this.y + Phaser.Math.Between(-15, 15),
            1, 0x444444, 0.6
        );
        
        this.scene.tweens.add({
            targets: debris,
            y: debris.y + Phaser.Math.Between(10, 30),
            alpha: 0,
            duration: 2000,
            ease: 'Power2.easeOut',
            onComplete: () => debris.destroy()
        });
    }
    
    takeDamage(amount = 50) {
        if (!this.isDestructible) return false;
        
        this.health -= amount;
        
        // Visual feedback
        this.scene.tweens.add({
            targets: this,
            tint: 0xff0000,
            duration: 200,
            yoyo: true,
            onComplete: () => {
                this.setTint(0xffffff);
            }
        });
        
        if (this.health <= 0) {
            this.destroyObstacle();
            return true;
        }
        
        return false;
    }
    
    destroyObstacle() {
        console.log(`${this.obstacleType} destroyed`);
        
        // Create destruction particles
        this.createDestructionParticles();
        
        // Remove from physics world
        this.destroy();
    }
    
    createDestructionParticles() {
        for (let i = 0; i < 8; i++) {
            const particle = this.scene.add.circle(
                this.x + Phaser.Math.Between(-10, 10),
                this.y + Phaser.Math.Between(-10, 10),
                Phaser.Math.Between(2, 5),
                this.color
            );
            
            this.scene.tweens.add({
                targets: particle,
                x: particle.x + Phaser.Math.Between(-50, 50),
                y: particle.y + Phaser.Math.Between(-50, 50),
                alpha: 0,
                duration: 1500,
                ease: 'Power2.easeOut',
                onComplete: () => particle.destroy()
            });
        }
    }
    
    getCollisionDamage() {
        switch (this.obstacleType) {
            case 'rock':
                return 30;
            case 'buoy':
                return 10;
            case 'boat':
                return 25;
            default:
                return 20;
        }
    }
    
    destroy() {
        // Clean up graphics and related objects
        if (this.obstacleGraphics) this.obstacleGraphics.destroy();
        if (this.leftLight) this.leftLight.destroy();
        if (this.rightLight) this.rightLight.destroy();
        if (this.ripples) this.ripples.destroy(true);
        
        super.destroy();
    }
}
