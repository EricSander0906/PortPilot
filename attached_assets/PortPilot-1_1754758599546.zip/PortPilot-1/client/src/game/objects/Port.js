import { GameConfig } from '../utils/GameConfig.js';
import { Utils } from '../utils/Utils.js';

/**
 * Port class - Docking stations for the ship
 */
export class Port extends Phaser.Physics.Arcade.Sprite {
    constructor(scene, x, y, portNumber) {
        super(scene, x, y, null);
        
        scene.add.existing(this);
        scene.physics.add.existing(this);
        
        this.scene = scene;
        this.portNumber = portNumber;
        this.isDocked = false;
        this.isActive = true;
        
        this.initializePort();
        this.createVisuals();
        
        console.log(`Port ${portNumber} created at`, x, y);
    }
    
    initializePort() {
        // Port properties
        this.dockingRadius = GameConfig.PORT_DOCK_DISTANCE;
        this.width = 40;
        this.height = 40;
        
        // Set physics body
        this.setSize(this.width, this.height);
        this.body.setImmovable(true);
        
        // Animation properties
        this.pulseDirection = 1;
        this.pulseSpeed = 0.002;
        this.currentPulse = 1;
    }
    
    createVisuals() {
        // Create port graphics
        this.portGraphics = this.scene.add.graphics();
        this.updatePortGraphics();
        
        // Create dock area indicator
        this.dockIndicator = this.scene.add.circle(this.x, this.y, this.dockingRadius, 0x00ff00, 0.1);
        this.dockIndicator.setStrokeStyle(2, 0x00ff00, 0.3);
        
        // Create port number display
        this.portText = this.scene.add.text(this.x, this.y - 50, this.portNumber.toString(), {
            fontSize: '16px',
            fill: '#ffffff',
            fontFamily: 'Arial',
            fontStyle: 'bold',
            stroke: '#000000',
            strokeThickness: 2
        }).setOrigin(0.5);
        
        // Create status indicator
        this.createStatusIndicator();
        
        // Animate dock indicator
        this.scene.tweens.add({
            targets: this.dockIndicator,
            alpha: 0.05,
            duration: 1500,
            yoyo: true,
            repeat: -1,
            ease: 'Sine.easeInOut'
        });
    }
    
    createStatusIndicator() {
        // Status light on top of port
        this.statusLight = this.scene.add.circle(this.x, this.y - 25, 6, 0x00ff00);
        this.statusLight.setStrokeStyle(2, 0xffffff);
        
        // Animate status light
        this.scene.tweens.add({
            targets: this.statusLight,
            scaleX: 1.2,
            scaleY: 1.2,
            alpha: 0.7,
            duration: 1000,
            yoyo: true,
            repeat: -1,
            ease: 'Sine.easeInOut'
        });
    }
    
    updatePortGraphics() {
        this.portGraphics.clear();
        
        // Port base structure
        const baseSize = 20 * this.currentPulse;
        
        if (this.isDocked) {
            // Docked state - green and larger
            this.portGraphics.fillStyle(0x00ff00);
            this.portGraphics.fillRect(this.x - baseSize, this.y - baseSize, baseSize * 2, baseSize * 2);
            this.portGraphics.lineStyle(3, 0xffffff);
            this.portGraphics.strokeRect(this.x - baseSize, this.y - baseSize, baseSize * 2, baseSize * 2);
        } else if (this.isActive) {
            // Active state - blue and pulsing
            this.portGraphics.fillStyle(0x0066cc);
            this.portGraphics.fillRect(this.x - baseSize, this.y - baseSize, baseSize * 2, baseSize * 2);
            this.portGraphics.lineStyle(2, 0x00aaff);
            this.portGraphics.strokeRect(this.x - baseSize, this.y - baseSize, baseSize * 2, baseSize * 2);
        } else {
            // Inactive state - gray
            this.portGraphics.fillStyle(0x666666);
            this.portGraphics.fillRect(this.x - baseSize, this.y - baseSize, baseSize * 2, baseSize * 2);
            this.portGraphics.lineStyle(2, 0x999999);
            this.portGraphics.strokeRect(this.x - baseSize, this.y - baseSize, baseSize * 2, baseSize * 2);
        }
        
        // Add port details
        this.addPortDetails(baseSize);
    }
    
    addPortDetails(baseSize) {
        // Docking cleat (small rectangles on sides)
        this.portGraphics.fillStyle(0x333333);
        this.portGraphics.fillRect(this.x - baseSize - 5, this.y - 5, 10, 10);
        this.portGraphics.fillRect(this.x + baseSize - 5, this.y - 5, 10, 10);
        
        // Port crane or structure
        this.portGraphics.lineStyle(3, 0x666666);
        this.portGraphics.beginPath();
        this.portGraphics.moveTo(this.x - 10, this.y - baseSize);
        this.portGraphics.lineTo(this.x - 10, this.y - baseSize - 15);
        this.portGraphics.lineTo(this.x + 10, this.y - baseSize - 15);
        this.portGraphics.lineTo(this.x + 10, this.y - baseSize);
        this.portGraphics.strokePath();
        
        // Port identification marker
        if (this.isActive && !this.isDocked) {
            this.portGraphics.fillStyle(0xffff00);
            this.portGraphics.fillCircle(this.x, this.y, 3);
        }
    }
    
    update(time, delta) {
        if (!this.isDocked && this.isActive) {
            // Pulse animation
            this.currentPulse += this.pulseDirection * this.pulseSpeed * delta;
            if (this.currentPulse >= 1.2) {
                this.currentPulse = 1.2;
                this.pulseDirection = -1;
            } else if (this.currentPulse <= 0.8) {
                this.currentPulse = 0.8;
                this.pulseDirection = 1;
            }
        }
        
        this.updatePortGraphics();
    }
    
    dock() {
        if (this.isDocked) return false;
        
        console.log(`Ship docked at port ${this.portNumber}`);
        
        this.isDocked = true;
        this.isActive = false;
        
        // Update visuals
        this.updateStatusVisuals();
        
        // Animate successful docking
        this.animateSuccessfulDock();
        
        return true;
    }
    
    updateStatusVisuals() {
        // Update status light
        if (this.statusLight) {
            this.statusLight.setFillStyle(0xff0000); // Red when docked
            this.scene.tweens.killTweensOf(this.statusLight);
        }
        
        // Update dock indicator
        if (this.dockIndicator) {
            this.dockIndicator.setStrokeStyle(2, 0xff0000, 0.5);
            this.scene.tweens.killTweensOf(this.dockIndicator);
            this.dockIndicator.setAlpha(0.2);
        }
        
        // Update port text
        if (this.portText) {
            this.portText.setColor('#00ff00');
            this.portText.setText(`${this.portNumber} ✓`);
        }
    }
    
    animateSuccessfulDock() {
        // Scale animation
        this.scene.tweens.add({
            targets: this,
            scaleX: 1.3,
            scaleY: 1.3,
            duration: 300,
            yoyo: true,
            ease: 'Back.easeOut'
        });
        
        // Success particles
        this.createSuccessParticles();
        
        // Success sound effect handled by Play scene
    }
    
    createSuccessParticles() {
        for (let i = 0; i < 12; i++) {
            const angle = (i / 12) * Math.PI * 2;
            const distance = 30;
            const startX = this.x + Math.cos(angle) * distance;
            const startY = this.y + Math.sin(angle) * distance;
            
            const particle = this.scene.add.circle(startX, startY, 4, 0x00ff00);
            
            this.scene.tweens.add({
                targets: particle,
                x: this.x + Math.cos(angle) * (distance + 50),
                y: this.y + Math.sin(angle) * (distance + 50),
                alpha: 0,
                scale: 0,
                duration: 1500,
                ease: 'Power2.easeOut',
                onComplete: () => particle.destroy()
            });
        }
    }
    
    undock() {
        if (!this.isDocked) return false;
        
        console.log(`Port ${this.portNumber} available again`);
        
        this.isDocked = false;
        this.isActive = true;
        this.currentPulse = 1;
        this.pulseDirection = 1;
        
        // Reset visuals
        this.resetVisuals();
        
        return true;
    }
    
    resetVisuals() {
        // Reset status light
        if (this.statusLight) {
            this.statusLight.setFillStyle(0x00ff00);
            this.scene.tweens.add({
                targets: this.statusLight,
                scaleX: 1.2,
                scaleY: 1.2,
                alpha: 0.7,
                duration: 1000,
                yoyo: true,
                repeat: -1,
                ease: 'Sine.easeInOut'
            });
        }
        
        // Reset dock indicator
        if (this.dockIndicator) {
            this.dockIndicator.setStrokeStyle(2, 0x00ff00, 0.3);
            this.scene.tweens.add({
                targets: this.dockIndicator,
                alpha: 0.05,
                duration: 1500,
                yoyo: true,
                repeat: -1,
                ease: 'Sine.easeInOut'
            });
        }
        
        // Reset port text
        if (this.portText) {
            this.portText.setColor('#ffffff');
            this.portText.setText(this.portNumber.toString());
        }
    }
    
    getDistance(ship) {
        return Utils.distance(this.x, this.y, ship.x, ship.y);
    }
    
    isInDockingRange(ship) {
        return this.getDistance(ship) <= this.dockingRadius;
    }
    
    destroy() {
        // Clean up graphics and UI elements
        if (this.portGraphics) this.portGraphics.destroy();
        if (this.dockIndicator) this.dockIndicator.destroy();
        if (this.portText) this.portText.destroy();
        if (this.statusLight) this.statusLight.destroy();
        
        super.destroy();
    }
}
