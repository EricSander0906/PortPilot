/**
 * Cloud class - Moving cloud shadows across the water
 */
export class Cloud extends Phaser.GameObjects.Graphics {
    constructor(scene, x, y, size = 1) {
        super(scene);
        
        scene.add.existing(this);
        
        this.scene = scene;
        this.cloudSize = size;
        this.speed = 15 + Math.random() * 10; // Random speed variation
        
        this.x = x;
        this.y = y;
        
        this.initializeCloud();
        this.createCloudShadow();
    }
    
    initializeCloud() {
        // Cloud movement direction (bottom-right to top-left)
        this.moveAngle = Math.PI * 1.25; // 225 degrees
        this.velocity = {
            x: Math.cos(this.moveAngle) * this.speed,
            y: Math.sin(this.moveAngle) * this.speed
        };
        
        // Cloud properties
        this.opacity = 0.15 + Math.random() * 0.1; // Slight opacity variation
        this.shadowRadius = 60 + (this.cloudSize * 40);
    }
    
    createCloudShadow() {
        this.clear();
        
        // Create cloud shadow - darker area on the water
        const gradient = this.scene.add.graphics();
        
        // Main shadow
        this.fillStyle(0x000040, this.opacity);
        this.fillCircle(0, 0, this.shadowRadius);
        
        // Inner darker core
        this.fillStyle(0x000060, this.opacity * 0.5);
        this.fillCircle(0, 0, this.shadowRadius * 0.6);
        
        // Soft edge effect
        this.lineStyle(10, 0x000080, this.opacity * 0.3);
        this.strokeCircle(0, 0, this.shadowRadius);
    }
    
    update(time, delta) {
        // Move cloud shadow
        this.x += this.velocity.x * (delta / 1000);
        this.y += this.velocity.y * (delta / 1000);
        
        // Remove cloud when it goes off screen (top-left)
        if (this.x < -100 || this.y < -100) {
            this.destroy();
            return true; // Signal for removal from cloud array
        }
        
        return false;
    }
    
    static spawnCloud(scene) {
        // Spawn clouds from bottom-right area
        const spawnX = scene.cameras.main.width + 50 + Math.random() * 100;
        const spawnY = scene.cameras.main.height + 50 + Math.random() * 100;
        const size = 0.5 + Math.random() * 1.5;
        
        return new Cloud(scene, spawnX, spawnY, size);
    }
}