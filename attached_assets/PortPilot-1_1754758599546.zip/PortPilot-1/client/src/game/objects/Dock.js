import { GameConfig } from '../utils/GameConfig.js';

/**
 * Dock class - Colored docking stations for cargo delivery
 */
export class Dock extends Phaser.Physics.Arcade.Sprite {
    constructor(scene, x, y, color, dockId) {
        super(scene, x, y, null);
        
        scene.add.existing(this);
        scene.physics.add.existing(this);
        
        this.scene = scene;
        this.color = color; // 'red' or 'yellow'
        this.dockId = dockId;
        this.isOccupied = false;
        this.occupyingBoat = null;
        
        this.initializeDock();
        this.createVisuals();
        
        console.log(`${color} dock ${dockId} created at`, x, y);
    }
    
    initializeDock() {
        // Dock properties
        this.width = 50;
        this.height = 50;
        this.dockingRadius = 35;
        
        // Set physics body
        this.setSize(this.width, this.height);
        this.body.setImmovable(true);
        
        // Color configuration
        this.dockColor = this.color === 'red' ? 0xff4444 : 0xffff44;
        this.dockColorDark = this.color === 'red' ? 0xcc0000 : 0xcccc00;
        
        // Animation properties
        this.pulsePhase = Math.random() * Math.PI * 2;
    }
    
    createVisuals() {
        // Create dock platform
        this.dockGraphics = this.scene.add.graphics();
        this.updateDockGraphics();
        
        // Create docking area indicator
        this.dockArea = this.scene.add.circle(this.x, this.y, this.dockingRadius, this.dockColor, 0.1);
        this.dockArea.setStrokeStyle(2, this.dockColor, 0.4);
        
        // Create dock label
        const labelText = this.color.charAt(0).toUpperCase() + this.color.slice(1);
        this.dockLabel = this.scene.add.text(this.x, this.y + 30, labelText, {
            fontSize: '12px',
            fill: this.color === 'red' ? '#ff4444' : '#ffff44',
            fontFamily: 'Arial',
            fontStyle: 'bold',
            stroke: '#000000',
            strokeThickness: 2
        }).setOrigin(0.5);
        
        // Create status indicators
        this.createStatusIndicators();
        
        // Animate docking area
        this.scene.tweens.add({
            targets: this.dockArea,
            alpha: 0.05,
            duration: 2000,
            yoyo: true,
            repeat: -1,
            ease: 'Sine.easeInOut'
        });
    }
    
    createStatusIndicators() {
        // Available/occupied indicator
        this.statusLight = this.scene.add.circle(this.x - 20, this.y - 20, 4, 0x00ff00);
        this.statusLight.setStrokeStyle(1, 0xffffff);
        
        // Cargo count indicator
        this.cargoCounter = this.scene.add.text(this.x + 20, this.y - 20, '0', {
            fontSize: '14px',
            fill: '#ffffff',
            fontFamily: 'Arial',
            fontStyle: 'bold',
            stroke: '#000000',
            strokeThickness: 2
        }).setOrigin(0.5);
    }
    
    updateDockGraphics() {
        this.dockGraphics.clear();
        
        // Main dock platform
        this.dockGraphics.fillStyle(this.dockColorDark);
        this.dockGraphics.fillRoundedRect(this.x - 25, this.y - 25, 50, 50, 8);
        
        // Dock surface
        this.dockGraphics.fillStyle(this.dockColor);
        this.dockGraphics.fillRoundedRect(this.x - 20, this.y - 20, 40, 40, 6);
        
        // Dock edges/posts
        this.dockGraphics.fillStyle(0x8B4513); // Brown wood color
        for (let i = 0; i < 4; i++) {
            const angle = (i * Math.PI) / 2;
            const postX = this.x + Math.cos(angle) * 18;
            const postY = this.y + Math.sin(angle) * 18;
            this.dockGraphics.fillRect(postX - 2, postY - 2, 4, 4);
        }
        
        // Dock outline
        this.dockGraphics.lineStyle(2, 0xffffff, 0.8);
        this.dockGraphics.strokeRoundedRect(this.x - 25, this.y - 25, 50, 50, 8);
        
        // Add subtle animation pulse
        const pulseScale = 1 + Math.sin(this.scene.time.now * 0.002 + this.pulsePhase) * 0.02;
        this.dockGraphics.setScale(pulseScale);
    }
    
    update(time, delta) {
        this.updateDockGraphics();
        this.updateStatusIndicators();
    }
    
    updateStatusIndicators() {
        // Update status light
        if (this.isOccupied) {
            this.statusLight.setFillStyle(0xff0000); // Red when occupied
        } else {
            this.statusLight.setFillStyle(0x00ff00); // Green when available
        }
        
        // Update cargo counter (could be used for delivered cargo count)
        // For now, just show if occupied
        this.cargoCounter.setText(this.isOccupied ? '1' : '0');
    }
    
    canAcceptBoat(boat) {
        if (this.isOccupied) return false;
        if (!boat.cargo.includes(this.color)) return false;
        
        const distance = Phaser.Math.Distance.Between(this.x, this.y, boat.x, boat.y);
        return distance <= this.dockingRadius;
    }
    
    dockBoat(boat) {
        if (!this.canAcceptBoat(boat)) return false;
        
        this.isOccupied = true;
        this.occupyingBoat = boat;
        
        // Unload matching cargo
        const unloaded = boat.unloadCargo(this.color);
        
        if (unloaded) {
            this.scene.audioManager.playDockSound();
            
            // Add score
            this.scene.addScore(100);
            
            // Visual feedback
            this.createDockingEffect();
            
            // Auto-release dock after brief moment
            this.scene.time.delayedCall(1000, () => {
                this.releaseDock();
            });
            
            return true;
        }
        
        return false;
    }
    
    releaseDock() {
        this.isOccupied = false;
        this.occupyingBoat = null;
    }
    
    createDockingEffect() {
        // Success particles
        const particles = this.scene.add.particles(this.x, this.y, 'star', {
            scale: { start: 0.2, end: 0 },
            speed: { min: 30, max: 60 },
            alpha: { start: 1, end: 0 },
            lifespan: 800,
            quantity: 5,
            emitZone: { type: 'edge', source: new Phaser.Geom.Circle(0, 0, 20), quantity: 5 }
        });
        
        this.scene.time.delayedCall(1000, () => {
            particles.destroy();
        });
        
        // Dock flash
        this.scene.tweens.add({
            targets: this.dockGraphics,
            alpha: 0.5,
            duration: 100,
            yoyo: true,
            repeat: 3
        });
    }
    
    checkBoatCollision(boat) {
        const distance = Phaser.Math.Distance.Between(this.x, this.y, boat.x, boat.y);
        
        if (distance <= this.dockingRadius && boat.cargo.includes(this.color)) {
            // Attempt to dock
            return this.dockBoat(boat);
        }
        
        return false;
    }
    
    destroy() {
        if (this.dockGraphics) this.dockGraphics.destroy();
        if (this.dockArea) this.dockArea.destroy();
        if (this.dockLabel) this.dockLabel.destroy();
        if (this.statusLight) this.statusLight.destroy();
        if (this.cargoCounter) this.cargoCounter.destroy();
        super.destroy();
    }
}