import { GameConfig } from '../utils/GameConfig.js';

/**
 * Boat class - Automatically spawning boats with cargo that can be dragged by mouse
 */
export class Boat extends Phaser.Physics.Arcade.Sprite {
    constructor(scene, x, y, cargoConfig) {
        super(scene, x, y, null);
        
        scene.add.existing(this);
        scene.physics.add.existing(this);
        
        this.scene = scene;
        this.initializeBoat(cargoConfig);
        this.setupPhysics();
        this.createVisuals();
        this.setupDragging();
        
        console.log('Boat created at', x, y, 'with cargo:', this.cargo);
    }
    
    initializeBoat(cargoConfig) {
        // Boat properties
        this.width = 24;
        this.height = 12;
        this.speed = GameConfig.BOAT_SPEED || 30;
        this.autoMoveSpeed = 20;
        
        // Cargo configuration - array of colors ('red', 'yellow')
        this.cargo = cargoConfig || ['red'];
        this.originalCargo = [...this.cargo]; // Keep track of original cargo
        
        // Movement state
        this.isPlayerControlled = false;
        this.isDragging = false;
        this.autoTarget = null;
        this.autoMoveTimer = 0;
        
        // Lifecycle
        this.lifeTimer = 0;
        this.maxLifeTime = 30000; // 30 seconds before auto-disappear
        
        // Collision warning
        this.warningCircle = null;
        this.isInDanger = false;
        
        // Visual state
        this.boatColor = this.cargo.length === 1 ? 
            (this.cargo[0] === 'red' ? 0xff4444 : 0xffff44) : 
            0x44ff44; // Green for mixed cargo
            
        // Dragging trail system
        this.dragTrail = [];
        this.maxTrailPoints = 8;
        this.trailGraphics = null;
        
        // Smooth movement
        this.targetX = x;
        this.targetY = y;
        this.smoothFactor = 0.15;
    }
    
    setupPhysics() {
        this.setSize(20, 10);
        this.setDisplaySize(this.width, this.height);
        this.setDrag(100);
        this.setMaxVelocity(this.speed * 2);
        this.body.setMass(1);
        this.setCollideWorldBounds(true);
    }
    
    createVisuals() {
        // Create boat graphics
        this.boatGraphics = this.scene.add.graphics();
        this.updateBoatGraphics();
        
        // Create cargo display
        this.cargoGraphics = this.scene.add.graphics();
        this.updateCargoDisplay();
        
        // Create warning circle (initially hidden)
        this.warningCircle = this.scene.add.circle(this.x, this.y, 30, 0xff0000, 0);
        this.warningCircle.setStrokeStyle(3, 0xff0000, 0.8);
        
        // Create trail graphics
        this.trailGraphics = this.scene.add.graphics();
    }
    
    setupDragging() {
        this.setInteractive();
        this.scene.input.setDraggable(this);
        
        this.on('dragstart', (pointer, dragX, dragY) => {
            this.startDragging();
        });
        
        this.on('drag', (pointer, dragX, dragY) => {
            this.updateDragPosition(dragX, dragY);
        });
        
        this.on('dragend', (pointer) => {
            this.stopDragging();
        });
    }
    
    startDragging() {
        this.isDragging = true;
        this.isPlayerControlled = true;
        this.setVelocity(0, 0);
        this.scene.audioManager.playClickSound();
        
        // Visual feedback
        this.setTint(0xaaffaa);
    }
    
    updateDragPosition(dragX, dragY) {
        if (this.isDragging) {
            // Add to drag trail
            this.addTrailPoint(this.x, this.y);
            
            // Smooth movement towards target
            this.targetX = dragX;
            this.targetY = dragY;
            
            // Update position with interpolation
            this.x = Phaser.Math.Linear(this.x, this.targetX, this.smoothFactor);
            this.y = Phaser.Math.Linear(this.y, this.targetY, this.smoothFactor);
            
            this.updateVisualPositions();
            this.updateTrailVisuals();
        }
    }
    
    stopDragging() {
        this.isDragging = false;
        this.clearTint();
        
        // Clear drag trail
        this.clearTrail();
        
        // Resume automatic movement after a delay
        this.scene.time.delayedCall(2000, () => {
            this.isPlayerControlled = false;
        });
    }
    
    update(time, delta) {
        this.lifeTimer += delta;
        
        // Auto-disappear if too old and no cargo
        if (this.cargo.length === 0 && this.lifeTimer > 5000) {
            this.disappear();
            return;
        }
        
        // Auto-disappear if maximum lifetime reached
        if (this.lifeTimer > this.maxLifeTime) {
            this.disappear();
            return;
        }
        
        // Update visuals
        this.updateBoatGraphics();
        this.updateCargoDisplay();
        this.updateWarningState();
        
        // Automatic movement when not player controlled
        if (!this.isPlayerControlled && !this.isDragging) {
            this.updateAutoMovement(delta);
        }
        
        // Smooth movement towards target position during dragging
        if (this.isDragging) {
            this.x = Phaser.Math.Linear(this.x, this.targetX, this.smoothFactor);
            this.y = Phaser.Math.Linear(this.y, this.targetY, this.smoothFactor);
            this.updateVisualPositions();
        }
    }
    
    updateAutoMovement(delta) {
        this.autoMoveTimer += delta;
        
        if (this.autoMoveTimer > 3000) { // Change direction every 3 seconds
            this.autoMoveTimer = 0;
            this.setRandomAutoTarget();
        }
        
        if (this.autoTarget) {
            const distance = Phaser.Math.Distance.Between(this.x, this.y, this.autoTarget.x, this.autoTarget.y);
            if (distance > 10) {
                const angle = Phaser.Math.Angle.Between(this.x, this.y, this.autoTarget.x, this.autoTarget.y);
                this.setVelocity(
                    Math.cos(angle) * this.autoMoveSpeed,
                    Math.sin(angle) * this.autoMoveSpeed
                );
            }
        }
    }
    
    setRandomAutoTarget() {
        this.autoTarget = {
            x: Phaser.Math.Between(50, this.scene.cameras.main.width - 50),
            y: Phaser.Math.Between(50, this.scene.cameras.main.height - 50)
        };
    }
    
    updateBoatGraphics() {
        this.boatGraphics.clear();
        
        // Boat body
        this.boatGraphics.fillStyle(this.boatColor);
        this.boatGraphics.fillRoundedRect(this.x - 12, this.y - 6, 24, 12, 2);
        
        // Boat outline
        this.boatGraphics.lineStyle(1, 0xffffff);
        this.boatGraphics.strokeRoundedRect(this.x - 12, this.y - 6, 24, 12, 2);
        
        // Direction indicator
        this.boatGraphics.fillStyle(0xffffff);
        this.boatGraphics.fillTriangle(
            this.x + 10, this.y,
            this.x + 6, this.y - 3,
            this.x + 6, this.y + 3
        );
    }
    
    updateCargoDisplay() {
        this.cargoGraphics.clear();
        
        // Draw cargo containers
        for (let i = 0; i < this.cargo.length; i++) {
            const cargoX = this.x - 8 + (i * 4);
            const cargoY = this.y - 2;
            const cargoColor = this.cargo[i] === 'red' ? 0xff0000 : 0xffff00;
            
            this.cargoGraphics.fillStyle(cargoColor);
            this.cargoGraphics.fillRect(cargoX, cargoY, 3, 4);
            
            this.cargoGraphics.lineStyle(1, 0x000000);
            this.cargoGraphics.strokeRect(cargoX, cargoY, 3, 4);
        }
        
        // Show cargo count
        if (this.cargo.length > 0) {
            const text = this.scene.add.text(this.x, this.y - 15, this.cargo.length.toString(), {
                fontSize: '10px',
                fill: '#ffffff',
                fontFamily: 'Arial',
                stroke: '#000000',
                strokeThickness: 1
            }).setOrigin(0.5);
            
            this.scene.time.delayedCall(100, () => {
                text.destroy();
            });
        }
    }
    
    updateWarningState() {
        // Check for nearby boats
        const nearbyBoats = this.scene.boats.filter(boat => {
            if (boat === this) return false;
            const distance = Phaser.Math.Distance.Between(this.x, this.y, boat.x, boat.y);
            return distance < 50;
        });
        
        const shouldShowWarning = nearbyBoats.length > 0;
        
        if (shouldShowWarning && !this.isInDanger) {
            this.showWarning();
        } else if (!shouldShowWarning && this.isInDanger) {
            this.hideWarning();
        }
        
        if (this.isInDanger) {
            this.warningCircle.x = this.x;
            this.warningCircle.y = this.y;
        }
    }
    
    showWarning() {
        this.isInDanger = true;
        this.warningCircle.setAlpha(0.6);
        this.scene.audioManager.playCollisionSound();
        
        // Pulse animation
        this.scene.tweens.add({
            targets: this.warningCircle,
            scaleX: 1.2,
            scaleY: 1.2,
            duration: 300,
            yoyo: true,
            repeat: -1
        });
    }
    
    hideWarning() {
        this.isInDanger = false;
        this.warningCircle.setAlpha(0);
        this.scene.tweens.killTweensOf(this.warningCircle);
        this.warningCircle.setScale(1);
    }
    
    updateVisualPositions() {
        // Update graphics positions when boat moves
        this.updateBoatGraphics();
        this.updateCargoDisplay();
        if (this.isInDanger) {
            this.warningCircle.x = this.x;
            this.warningCircle.y = this.y;
        }
    }
    
    addTrailPoint(x, y) {
        this.dragTrail.push({ x, y, time: Date.now() });
        
        // Remove old trail points
        if (this.dragTrail.length > this.maxTrailPoints) {
            this.dragTrail.shift();
        }
    }
    
    updateTrailVisuals() {
        if (!this.trailGraphics || this.dragTrail.length < 2) return;
        
        this.trailGraphics.clear();
        
        // Draw trail line
        this.trailGraphics.lineStyle(4, 0x88aaff, 0.6);
        this.trailGraphics.beginPath();
        
        for (let i = 0; i < this.dragTrail.length; i++) {
            const point = this.dragTrail[i];
            const alpha = (i / this.dragTrail.length) * 0.8;
            
            if (i === 0) {
                this.trailGraphics.moveTo(point.x, point.y);
            } else {
                this.trailGraphics.lineTo(point.x, point.y);
            }
        }
        
        this.trailGraphics.strokePath();
        
        // Draw trail dots
        for (let i = 0; i < this.dragTrail.length; i++) {
            const point = this.dragTrail[i];
            const alpha = (i / this.dragTrail.length) * 0.6;
            const size = 2 + (i / this.dragTrail.length) * 2;
            
            this.trailGraphics.fillStyle(0x88aaff, alpha);
            this.trailGraphics.fillCircle(point.x, point.y, size);
        }
    }
    
    clearTrail() {
        this.dragTrail = [];
        if (this.trailGraphics) {
            this.trailGraphics.clear();
        }
    }
    
    unloadCargo(color) {
        const index = this.cargo.indexOf(color);
        if (index !== -1) {
            this.cargo.splice(index, 1);
            this.scene.audioManager.playSuccessSound();
            
            // Visual feedback
            const star = this.scene.add.circle(this.x, this.y - 20, 5, 0xffff00);
            this.scene.tweens.add({
                targets: star,
                y: this.y - 40,
                alpha: 0,
                scale: 2,
                duration: 1000,
                onComplete: () => star.destroy()
            });
            
            return true;
        }
        return false;
    }
    
    disappear() {
        this.hideWarning();
        
        // Fade out animation
        this.scene.tweens.add({
            targets: [this, this.boatGraphics, this.cargoGraphics],
            alpha: 0,
            scale: 0.5,
            duration: 500,
            onComplete: () => {
                this.destroy();
            }
        });
        
        // Remove from boats array
        const index = this.scene.boats.indexOf(this);
        if (index !== -1) {
            this.scene.boats.splice(index, 1);
        }
    }
    
    destroy() {
        if (this.boatGraphics) this.boatGraphics.destroy();
        if (this.cargoGraphics) this.cargoGraphics.destroy();
        if (this.warningCircle) this.warningCircle.destroy();
        if (this.trailGraphics) this.trailGraphics.destroy();
        super.destroy();
    }
}