import { GameConfig } from '../utils/GameConfig.js';
import { Utils } from '../utils/Utils.js';

/**
 * Ship class - Player controlled vessel
 */
export class Ship extends Phaser.Physics.Arcade.Sprite {
    constructor(scene, x, y) {
        // Create ship as a simple colored rectangle initially
        super(scene, x, y, null);
        
        scene.add.existing(this);
        scene.physics.add.existing(this);
        
        this.scene = scene;
        this.initializeShip();
        this.setupPhysics();
        this.createVisuals();
        this.setupInput();
        
        console.log('Ship created at', x, y);
    }
    
    initializeShip() {
        // Ship properties
        this.maxHealth = 100;
        this.health = this.maxHealth;
        this.speed = GameConfig.SHIP_SPEED;
        this.rotationSpeed = GameConfig.SHIP_ROTATION_SPEED;
        this.isThrusting = false;
        this.thrustPower = 0;
        
        // Visual properties
        this.width = 32;
        this.height = 16;
        
        // Trail effect
        this.trailPoints = [];
        this.maxTrailPoints = 10;
        
        // Sound effects
        this.engineSound = null;
    }
    
    setupPhysics() {
        // Set collision body
        this.setSize(28, 14);
        this.setDisplaySize(this.width, this.height);
        
        // Physics properties
        this.setDrag(GameConfig.SHIP_DRAG * 100);
        this.setAngularDrag(300);
        this.setMaxVelocity(this.speed);
        
        // Set mass
        this.body.setMass(1);
        
        // Collision bounds
        this.setCollideWorldBounds(true);
        this.body.onWorldBounds = true;
    }
    
    createVisuals() {
        // Create ship graphics
        this.shipGraphics = this.scene.add.graphics();
        this.updateShipGraphics();
        
        // Create health bar
        this.createHealthBar();
        
        // Create thrust particles
        this.thrustParticles = this.scene.add.particles(this.x, this.y, 'splash', {
            scale: { start: 0.1, end: 0 },
            speed: { min: 20, max: 50 },
            alpha: { start: 0.6, end: 0 },
            lifespan: 300,
            emitting: false,
            frequency: 20
        });
    }
    
    updateShipGraphics() {
        this.shipGraphics.clear();
        
        // Ship body (triangle pointing right)
        this.shipGraphics.fillStyle(0x00aaff);
        this.shipGraphics.fillTriangle(
            this.x + 16, this.y,      // Bow (front)
            this.x - 16, this.y - 8,  // Port stern
            this.x - 16, this.y + 8   // Starboard stern
        );
        
        // Ship outline
        this.shipGraphics.lineStyle(2, 0xffffff);
        this.shipGraphics.strokeTriangle(
            this.x + 16, this.y,
            this.x - 16, this.y - 8,
            this.x - 16, this.y + 8
        );
        
        // Cabin/bridge
        this.shipGraphics.fillStyle(0x0066cc);
        this.shipGraphics.fillRect(this.x - 8, this.y - 4, 12, 8);
        
        // Engine glow when thrusting
        if (this.isThrusting) {
            const glowSize = 3 + Math.sin(this.scene.time.now * 0.01) * 2;
            this.shipGraphics.fillStyle(0xff6600, 0.8);
            this.shipGraphics.fillCircle(this.x - 16, this.y, glowSize);
        }
        
        // Damage indicators
        if (this.health < this.maxHealth * 0.5) {
            // Smoke particles when damaged
            if (Math.random() < 0.1) {
                const smoke = this.scene.add.circle(
                    this.x + Phaser.Math.Between(-10, 10),
                    this.y + Phaser.Math.Between(-5, 5),
                    3, 0x666666, 0.5
                );
                
                this.scene.tweens.add({
                    targets: smoke,
                    alpha: 0,
                    scale: 2,
                    y: smoke.y - 20,
                    duration: 1000,
                    onComplete: () => smoke.destroy()
                });
            }
        }
    }
    
    createHealthBar() {
        this.healthBarBg = this.scene.add.rectangle(this.x, this.y - 25, 30, 4, 0x660000);
        this.healthBar = this.scene.add.rectangle(this.x - 15, this.y - 25, 30, 4, 0x00ff00);
        this.healthBar.setOrigin(0, 0.5);
    }
    
    updateHealthBar() {
        if (this.healthBar && this.healthBarBg) {
            this.healthBarBg.x = this.x;
            this.healthBarBg.y = this.y - 25;
            this.healthBar.x = this.x - 15;
            this.healthBar.y = this.y - 25;
            
            const healthPercent = this.health / this.maxHealth;
            this.healthBar.scaleX = healthPercent;
            
            // Change color based on health
            if (healthPercent > 0.6) {
                this.healthBar.setFillStyle(0x00ff00);
            } else if (healthPercent > 0.3) {
                this.healthBar.setFillStyle(0xffff00);
            } else {
                this.healthBar.setFillStyle(0xff0000);
            }
            
            // Hide when at full health
            this.healthBar.setVisible(healthPercent < 1);
            this.healthBarBg.setVisible(healthPercent < 1);
        }
    }
    
    setupInput() {
        // Get input manager reference
        this.cursors = this.scene.cursors;
        this.wasd = this.scene.wasd;
    }
    
    update(time, delta) {
        this.handleInput(delta);
        this.updatePhysics(delta);
        this.updateVisuals();
        this.updateTrail();
        this.updateHealthBar();
        
        // Keep ship in bounds with proper wrapping
        this.keepInBounds();
    }
    
    handleInput(delta) {
        const inputManager = this.scene.inputManager;
        if (!inputManager) return;
        
        const rotationDelta = (this.rotationSpeed * delta) / 1000;
        this.isThrusting = false;
        
        // Rotation
        if (inputManager.isLeftPressed()) {
            this.setAngularVelocity(-200);
        } else if (inputManager.isRightPressed()) {
            this.setAngularVelocity(200);
        } else {
            this.setAngularVelocity(0);
        }
        
        // Thrust
        if (inputManager.isUpPressed()) {
            this.thrust();
            this.isThrusting = true;
        }
        
        // Reverse
        if (inputManager.isDownPressed()) {
            this.reverse();
        }
        
        // Update thrust particles
        if (this.thrustParticles) {
            if (this.isThrusting) {
                this.thrustParticles.setPosition(
                    this.x - Math.cos(this.rotation) * 20,
                    this.y - Math.sin(this.rotation) * 20
                );
                this.thrustParticles.start();
            } else {
                this.thrustParticles.stop();
            }
        }
    }
    
    thrust() {
        const force = 300;
        const thrustX = Math.cos(this.rotation) * force;
        const thrustY = Math.sin(this.rotation) * force;
        
        this.setAcceleration(thrustX, thrustY);
    }
    
    reverse() {
        const force = 150;
        const thrustX = -Math.cos(this.rotation) * force;
        const thrustY = -Math.sin(this.rotation) * force;
        
        this.setAcceleration(thrustX, thrustY);
    }
    
    updatePhysics(delta) {
        // Apply water resistance
        this.body.velocity.x *= GameConfig.WATER_RESISTANCE;
        this.body.velocity.y *= GameConfig.WATER_RESISTANCE;
        
        // Reset acceleration when not thrusting
        if (!this.isThrusting && !this.scene.inputManager?.isDownPressed()) {
            this.setAcceleration(0, 0);
        }
        
        // Limit max velocity
        const velocity = this.body.velocity;
        const speed = velocity.length();
        if (speed > this.speed) {
            velocity.normalize().scale(this.speed);
            this.setVelocity(velocity.x, velocity.y);
        }
    }
    
    updateVisuals() {
        this.updateShipGraphics();
        
        // Update ship tilt based on turn rate
        const angularVel = this.body.angularVelocity;
        const tilt = Utils.clamp(angularVel * 0.001, -0.1, 0.1);
        this.setRotation(this.rotation);
    }
    
    updateTrail() {
        // Add current position to trail
        this.trailPoints.push({ x: this.x, y: this.y, time: this.scene.time.now });
        
        // Remove old trail points
        while (this.trailPoints.length > this.maxTrailPoints) {
            this.trailPoints.shift();
        }
        
        // Draw trail (simplified - in a real implementation you'd use a graphics object)
        if (this.body.velocity.length() > 50) {
            if (Math.random() < 0.3) {
                const trail = this.scene.add.circle(
                    this.x + Phaser.Math.Between(-5, 5),
                    this.y + Phaser.Math.Between(-5, 5),
                    2, 0x66ccff, 0.4
                );
                
                this.scene.tweens.add({
                    targets: trail,
                    alpha: 0,
                    scale: 0.5,
                    duration: 2000,
                    onComplete: () => trail.destroy()
                });
            }
        }
    }
    
    keepInBounds() {
        const bounds = {
            left: 20,
            right: GameConfig.GAME_WIDTH - 20,
            top: 20,
            bottom: GameConfig.GAME_HEIGHT - 20
        };
        
        Utils.keepInBounds(this, bounds, 10);
    }
    
    takeDamage(amount = 25) {
        this.health = Math.max(0, this.health - amount);
        
        // Visual feedback
        this.scene.tweens.add({
            targets: this,
            tint: 0xff0000,
            duration: 200,
            yoyo: true,
            onComplete: () => {
                this.setTint(0xffffff);
            }
        });
        
        console.log(`Ship took ${amount} damage, health: ${this.health}`);
        
        return this.health <= 0;
    }
    
    repair(amount = 25) {
        this.health = Math.min(this.maxHealth, this.health + amount);
        
        // Visual feedback
        this.scene.tweens.add({
            targets: this,
            tint: 0x00ff00,
            duration: 300,
            yoyo: true,
            onComplete: () => {
                this.setTint(0xffffff);
            }
        });
    }
    
    destroy() {
        // Clean up graphics and particles
        if (this.shipGraphics) this.shipGraphics.destroy();
        if (this.healthBar) this.healthBar.destroy();
        if (this.healthBarBg) this.healthBarBg.destroy();
        if (this.thrustParticles) this.thrustParticles.destroy();
        
        super.destroy();
    }
}
