import { GameConfig } from './utils/GameConfig.js';
import { AudioManager } from './managers/AudioManager.js';

/**
 * Menu Scene - Main game menu
 */
export class Menu extends Phaser.Scene {
    constructor() {
        super({ key: 'Menu' });
    }
    
    create() {
        console.log('Menu scene started');
        
        // Initialize audio manager
        this.audioManager = new AudioManager(this);
        
        this.createBackground();
        this.createTitle();
        this.createMenu();
        this.createCredits();
        this.setupInput();
        
        // Fade in
        this.cameras.main.fadeIn(500, 0, 0, 0);
        
        // Start background music
        this.audioManager.playBackgroundMusic();
    }
    
    createBackground() {
        const centerX = GameConfig.GAME_WIDTH / 2;
        const centerY = GameConfig.GAME_HEIGHT / 2;
        
        // Animated water background
        this.add.rectangle(centerX, centerY, GameConfig.GAME_WIDTH, GameConfig.GAME_HEIGHT, 0x004488);
        
        // Create animated water effect
        this.waterTiles = [];
        for (let i = 0; i < 6; i++) {
            const water = this.add.rectangle(
                (GameConfig.GAME_WIDTH / 6) * i + GameConfig.GAME_WIDTH / 12,
                centerY,
                GameConfig.GAME_WIDTH / 6,
                GameConfig.GAME_HEIGHT,
                0x0066aa
            );
            water.alpha = 0.3;
            this.waterTiles.push(water);
            
            // Animate water tiles
            this.tweens.add({
                targets: water,
                alpha: 0.1,
                duration: 2000 + (i * 200),
                yoyo: true,
                repeat: -1,
                ease: 'Sine.easeInOut'
            });
        }
        
        // Add floating elements
        this.createFloatingElements();
    }
    
    createFloatingElements() {
        // Create some ambient ships/buoys
        for (let i = 0; i < 3; i++) {
            const x = Phaser.Math.Between(50, GameConfig.GAME_WIDTH - 50);
            const y = Phaser.Math.Between(100, GameConfig.GAME_HEIGHT - 100);
            
            const element = this.add.circle(x, y, 8, 0x666666);
            element.alpha = 0.5;
            
            // Floating animation
            this.tweens.add({
                targets: element,
                y: y + Phaser.Math.Between(-20, 20),
                duration: 3000 + Phaser.Math.Between(0, 1000),
                yoyo: true,
                repeat: -1,
                ease: 'Sine.easeInOut'
            });
        }
    }
    
    createTitle() {
        const centerX = GameConfig.GAME_WIDTH / 2;
        
        // Main title
        const title = this.add.text(centerX, 120, 'PORT PILOT', {
            fontSize: '64px',
            fill: '#ffffff',
            fontFamily: 'Arial',
            fontStyle: 'bold',
            stroke: '#003366',
            strokeThickness: 4
        }).setOrigin(0.5);
        
        // Subtitle
        this.add.text(centerX, 180, 'Navigate the Harbor - Dock with Precision', {
            fontSize: '20px',
            fill: '#ffff99',
            fontFamily: 'Arial',
            fontStyle: 'italic'
        }).setOrigin(0.5);
        
        // Title animation
        this.tweens.add({
            targets: title,
            scaleX: 1.05,
            scaleY: 1.05,
            duration: 2000,
            yoyo: true,
            repeat: -1,
            ease: 'Sine.easeInOut'
        });
    }
    
    createMenu() {
        const centerX = GameConfig.GAME_WIDTH / 2;
        const startY = 280;
        const buttonSpacing = 60;
        
        // Menu buttons
        this.menuButtons = [];
        
        // Play button
        const playButton = this.createMenuButton(centerX, startY, 'START GAME', () => {
            this.startGame();
        });
        this.menuButtons.push(playButton);
        
        // Instructions button
        const instructionsButton = this.createMenuButton(centerX, startY + buttonSpacing, 'INSTRUCTIONS', () => {
            this.showInstructions();
        });
        this.menuButtons.push(instructionsButton);
        
        // High scores button
        const scoresButton = this.createMenuButton(centerX, startY + buttonSpacing * 2, 'HIGH SCORES', () => {
            this.showHighScores();
        });
        this.menuButtons.push(scoresButton);
        
        // Sound toggle button
        const soundText = this.audioManager && this.audioManager.isMuted ? 'SOUND: OFF' : 'SOUND: ON';
        const soundButton = this.createMenuButton(centerX, startY + buttonSpacing * 3, soundText, () => {
            this.toggleSound();
        });
        this.menuButtons.push(soundButton);
        this.soundButton = soundButton;
    }
    
    createMenuButton(x, y, text, callback) {
        // Button background
        const bg = this.add.rectangle(x, y, 200, 40, 0x003366);
        bg.setStrokeStyle(2, 0x0066cc);
        
        // Button text
        const buttonText = this.add.text(x, y, text, {
            fontSize: '18px',
            fill: '#ffffff',
            fontFamily: 'Arial',
            fontStyle: 'bold'
        }).setOrigin(0.5);
        
        // Make interactive
        bg.setInteractive({ useHandCursor: true });
        
        // Hover effects
        bg.on('pointerover', () => {
            bg.setFillStyle(0x0066cc);
            buttonText.setScale(1.1);
            this.audioManager.playHoverSound();
        });
        
        bg.on('pointerout', () => {
            bg.setFillStyle(0x003366);
            buttonText.setScale(1.0);
        });
        
        bg.on('pointerdown', () => {
            bg.setFillStyle(0x004488);
            buttonText.setScale(0.95);
        });
        
        bg.on('pointerup', () => {
            bg.setFillStyle(0x0066cc);
            buttonText.setScale(1.1);
            this.audioManager.playClickSound();
            callback();
        });
        
        return { bg, text: buttonText };
    }
    
    createCredits() {
        const centerX = GameConfig.GAME_WIDTH / 2;
        const bottomY = GameConfig.GAME_HEIGHT - 30;
        
        this.add.text(centerX, bottomY, 'HTML5 Conversion - Original Flash Game Recreated', {
            fontSize: '12px',
            fill: '#cccccc',
            fontFamily: 'Arial',
            alpha: 0.7
        }).setOrigin(0.5);
        
        // High score display
        const highScore = this.registry.get('highScore');
        this.add.text(centerX, bottomY - 20, `Best Score: ${highScore.toLocaleString()}`, {
            fontSize: '14px',
            fill: '#ffff99',
            fontFamily: 'Arial'
        }).setOrigin(0.5);
    }
    
    setupInput() {
        // Keyboard shortcuts
        this.input.keyboard.on('keydown-SPACE', () => {
            this.startGame();
        });
        
        this.input.keyboard.on('keydown-I', () => {
            this.showInstructions();
        });
    }
    
    startGame() {
        this.cameras.main.fadeOut(300, 0, 0, 0);
        this.cameras.main.once('camerafadeoutcomplete', () => {
            this.audioManager.stopBackgroundMusic();
            this.scene.start('Play');
        });
    }
    
    showInstructions() {
        // Create instructions overlay
        const overlay = this.add.rectangle(
            GameConfig.GAME_WIDTH / 2,
            GameConfig.GAME_HEIGHT / 2,
            GameConfig.GAME_WIDTH - 100,
            GameConfig.GAME_HEIGHT - 100,
            0x000033,
            0.9
        );
        overlay.setStrokeStyle(3, 0x0066cc);
        
        const instructions = [
            'HOW TO PLAY',
            '',
            'Use ARROW KEYS or WASD to steer your ship',
            'Navigate carefully through the harbor',
            'Dock at ports to score points',
            'Avoid obstacles and other ships',
            'Complete each level before time runs out',
            '',
            'SCORING:',
            '• Successful dock: 100 points',
            '• Time bonus at level end',
            '• Perfect docking gives extra points',
            '',
            'Press ESC or click to return to menu'
        ];
        
        const instructionText = this.add.text(
            GameConfig.GAME_WIDTH / 2,
            GameConfig.GAME_HEIGHT / 2 - 50,
            instructions.join('\n'),
            {
                fontSize: '16px',
                fill: '#ffffff',
                fontFamily: 'Arial',
                align: 'center',
                lineSpacing: 8
            }
        ).setOrigin(0.5);
        
        // Close instruction handler
        const closeInstructions = () => {
            overlay.destroy();
            instructionText.destroy();
        };
        
        overlay.setInteractive();
        overlay.on('pointerdown', closeInstructions);
        
        this.input.keyboard.once('keydown-ESC', closeInstructions);
    }
    
    showHighScores() {
        // Simple high score display - in a real implementation, 
        // this would load from a persistent storage system
        const highScore = this.registry.get('highScore');
        
        const overlay = this.add.rectangle(
            GameConfig.GAME_WIDTH / 2,
            GameConfig.GAME_HEIGHT / 2,
            300,
            200,
            0x000033,
            0.9
        );
        overlay.setStrokeStyle(3, 0x0066cc);
        
        const scoreText = this.add.text(
            GameConfig.GAME_WIDTH / 2,
            GameConfig.GAME_HEIGHT / 2,
            `HIGH SCORES\n\n1. ${highScore.toLocaleString()}\n\nClick to close`,
            {
                fontSize: '18px',
                fill: '#ffffff',
                fontFamily: 'Arial',
                align: 'center',
                lineSpacing: 10
            }
        ).setOrigin(0.5);
        
        overlay.setInteractive();
        overlay.on('pointerdown', () => {
            overlay.destroy();
            scoreText.destroy();
        });
    }
    
    toggleSound() {
        this.audioManager.toggleMute();
        const soundText = this.audioManager.isMuted ? 'SOUND: OFF' : 'SOUND: ON';
        this.soundButton.text.setText(soundText);
    }
}
