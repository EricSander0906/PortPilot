import { GameConfig } from './utils/GameConfig.js';

/**
 * Preload Scene - Load all game assets
 */
export class Preload extends Phaser.Scene {
    constructor() {
        super({ key: 'Preload' });
    }
    
    preload() {
        console.log('Loading game assets...');
        
        // Update loading display
        this.createLoadingScreen();
        
        // Load images
        this.loadImages();
        
        // Load audio
        this.loadAudio();
        
        // Load JSON data
        this.loadData();
        
        // Set up loading progress
        this.setupLoadingProgress();
    }
    
    create() {
        console.log('All assets loaded');
        
        // Fade out loading screen
        this.cameras.main.fadeOut(500, 0, 0, 0);
        
        this.cameras.main.once('camerafadeoutcomplete', () => {
            this.scene.start('Menu');
        });
    }
    
    createLoadingScreen() {
        const centerX = GameConfig.GAME_WIDTH / 2;
        const centerY = GameConfig.GAME_HEIGHT / 2;
        
        // Background
        this.add.rectangle(centerX, centerY, GameConfig.GAME_WIDTH, GameConfig.GAME_HEIGHT, 0x001133);
        
        // Title
        this.titleText = this.add.text(centerX, centerY - 100, 'PORT PILOT', {
            fontSize: '48px',
            fill: '#ffffff',
            fontFamily: 'Arial',
            fontStyle: 'bold'
        }).setOrigin(0.5);
        
        // Subtitle
        this.add.text(centerX, centerY - 50, 'HTML5 Edition', {
            fontSize: '24px',
            fill: '#ffff00',
            fontFamily: 'Arial'
        }).setOrigin(0.5);
        
        // Loading text
        this.loadingText = this.add.text(centerX, centerY + 50, 'Loading Assets...', {
            fontSize: '18px',
            fill: '#cccccc',
            fontFamily: 'Arial'
        }).setOrigin(0.5);
        
        // Progress bar
        this.progressBg = this.add.rectangle(centerX, centerY + 100, 400, 24, 0x003366);
        this.progressBg.setStrokeStyle(2, 0x006699);
        
        this.progressBar = this.add.rectangle(centerX - 198, centerY + 100, 4, 20, 0x00ccff);
        this.progressBar.setOrigin(0, 0.5);
        
        // Animate title
        this.tweens.add({
            targets: this.titleText,
            scaleX: 1.1,
            scaleY: 1.1,
            duration: 1000,
            yoyo: true,
            repeat: -1,
            ease: 'Sine.easeInOut'
        });
    }
    
    loadImages() {
        // Create simple particle textures programmatically since the game uses graphics objects
        this.createParticleTextures();
        
        console.log('Using programmatically generated graphics - no external images needed');
    }
    
    createParticleTextures() {
        // Create simple 4x4 particle textures for effects
        
        // Splash particle (blue dot)
        const splashGraphics = this.add.graphics();
        splashGraphics.fillStyle(0x66ccff);
        splashGraphics.fillCircle(2, 2, 2);
        splashGraphics.generateTexture('splash', 4, 4);
        splashGraphics.destroy();
        
        // Smoke particle (gray dot)
        const smokeGraphics = this.add.graphics();
        smokeGraphics.fillStyle(0x666666);
        smokeGraphics.fillCircle(2, 2, 2);
        smokeGraphics.generateTexture('smoke', 4, 4);
        smokeGraphics.destroy();
        
        // Star particle (yellow star)
        const starGraphics = this.add.graphics();
        starGraphics.fillStyle(0xffff00);
        starGraphics.fillCircle(2, 2, 2);
        starGraphics.generateTexture('star', 4, 4);
        starGraphics.destroy();
    }
    
    loadAudio() {
        // Use existing audio files from the public folder
        this.load.audio('background_music', ['/sounds/background.mp3']);
        this.load.audio('hit_sound', ['/sounds/hit.mp3']);
        this.load.audio('success_sound', ['/sounds/success.mp3']);
        
        // Additional game sounds (using existing as base)
        this.load.audio('engine_sound', ['/sounds/background.mp3']); // Will modify volume/pitch
        this.load.audio('dock_sound', ['/sounds/success.mp3']);
        this.load.audio('collision_sound', ['/sounds/hit.mp3']);
    }
    
    loadData() {
        // Load animation data
        this.load.json('ship_animations', '/assets/json/ship_animations.json');
        
        // Load level configurations
        this.load.json('levels', '/assets/json/levels.json');
    }
    
    setupLoadingProgress() {
        this.load.on('progress', (value) => {
            // Update progress bar
            this.progressBar.width = 396 * value;
            
            // Update loading text
            const percent = Math.floor(value * 100);
            this.loadingText.setText(`Loading Assets... ${percent}%`);
        });
        
        this.load.on('fileprogress', (file) => {
            console.log(`Loading: ${file.key}`);
        });
        
        this.load.on('complete', () => {
            this.loadingText.setText('Ready to Sail!');
            console.log('Asset loading complete');
        });
    }
}
