import { GameConfig } from './utils/GameConfig.js';

/**
 * Boot Scene - Initial game setup and configuration
 */
export class Boot extends Phaser.Scene {
    constructor() {
        super({ key: 'Boot' });
    }
    
    preload() {
        // Create loading progress bar
        this.createLoadingBar();
        
        // No external images needed - using programmatic graphics
        console.log('Boot assets ready - using programmatic UI');
    }
    
    create() {
        console.log('Boot scene started');
        
        // Set up global game data
        this.registry.set('score', 0);
        this.registry.set('lives', GameConfig.MAX_LIVES);
        this.registry.set('level', 1);
        this.registry.set('highScore', this.getHighScore());
        
        // Set up input handling
        this.input.mouse.disableContextMenu();
        
        // Start preload scene
        this.scene.start('Preload');
    }
    
    createLoadingBar() {
        const centerX = GameConfig.GAME_WIDTH / 2;
        const centerY = GameConfig.GAME_HEIGHT / 2;
        
        // Create simple loading text
        this.add.text(centerX, centerY - 50, 'Port Pilot', {
            fontSize: '32px',
            fill: GameConfig.COLOR_PRIMARY,
            fontFamily: GameConfig.FONT_FAMILY
        }).setOrigin(0.5);
        
        this.add.text(centerX, centerY, 'Loading...', {
            fontSize: '18px',
            fill: GameConfig.COLOR_SECONDARY,
            fontFamily: GameConfig.FONT_FAMILY
        }).setOrigin(0.5);
        
        // Create progress bar background
        const progressBg = this.add.rectangle(centerX, centerY + 50, 300, 20, 0x003366);
        progressBg.setStrokeStyle(2, 0xffffff);
        
        // Create progress bar fill
        this.progressBar = this.add.rectangle(centerX - 148, centerY + 50, 4, 16, 0x00ff00);
        this.progressBar.setOrigin(0, 0.5);
        
        // Listen for progress events
        this.load.on('progress', (value) => {
            this.progressBar.width = 296 * value;
        });
    }
    
    getHighScore() {
        try {
            return parseInt(localStorage.getItem('portPilot_highScore') || '0');
        } catch (e) {
            return 0;
        }
    }
    
    saveHighScore(score) {
        try {
            localStorage.setItem('portPilot_highScore', score.toString());
        } catch (e) {
            console.warn('Could not save high score');
        }
    }
}
