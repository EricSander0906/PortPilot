# Port Pilot - HTML5 Edition

A complete HTML5 conversion of the classic Flash harbor navigation game. Navigate your ship through busy harbors, dock at ports, and avoid obstacles in this faithful recreation using modern web technologies.

![Port Pilot](https://img.shields.io/badge/Status-Complete-success)
![HTML5](https://img.shields.io/badge/HTML5-Game-orange)
![Phaser3](https://img.shields.io/badge/Phaser-3.70.0-blue)

## 🎮 Game Features

### Core Gameplay
- **Ship Navigation**: Smooth, physics-based ship movement with realistic water resistance
- **Harbor Docking**: Precision docking system requiring careful speed control
- **Obstacle Avoidance**: Dynamic hazards including rocks, buoys, and moving boats
- **Progressive Difficulty**: Multiple levels with increasing challenges
- **Scoring System**: Points for successful docking with time and precision bonuses

### Technical Features
- **Full HTML5 Conversion**: Complete recreation from original Flash version
- **Cross-Platform**: Works on desktop and mobile devices
- **Responsive Design**: Automatically scales to different screen sizes
- **Modern Web Standards**: ES6+ JavaScript, Canvas/WebGL rendering
- **Touch Controls**: Virtual joystick for mobile devices
- **Audio System**: Background music and sound effects
- **Save System**: High score persistence using localStorage

## 🚀 Getting Started

### Prerequisites
- Modern web browser (Chrome 60+, Firefox 55+, Safari 12+, Edge 79+)
- Web server (for local development) or deploy to any hosting platform

### Quick Start
1. **Clone or download** this repository
2. **Start a web server** in the project directory:
   ```bash
   # Using Python 3
   python -m http.server 5000
   
   # Using Node.js (if you have http-server installed)
   npx http-server -p 5000
   
   # Using PHP
   php -S localhost:5000
   ```
3. **Open your browser** and navigate to `http://localhost:5000`
4. **Start playing!** The game will automatically load and begin

### Alternative Setup (No Server Required)
For development or quick testing, you can also:
1. Open `client/index.html` directly in your browser
2. Note: Some browsers may restrict local file access for audio/assets

## 🎯 How to Play

### Controls
- **Desktop**: 
  - Arrow Keys or WASD to steer
  - ESC to pause
  - P to pause/unpause
  - M to toggle mute
  
- **Mobile**: 
  - Touch and drag for virtual joystick control
  - Tap menu buttons for navigation

### Gameplay
1. **Navigate** your ship using the controls
2. **Approach ports** slowly to dock successfully
3. **Avoid obstacles** like rocks, buoys, and other boats
4. **Complete all docks** before time runs out
5. **Progress** through increasingly difficult levels

### Scoring
- **Successful Dock**: 100 points
- **Perfect Dock** (very slow approach): 200 points
- **Time Bonus**: Remaining time × 10 at level completion
- **High Scores**: Automatically saved locally

## 🏗️ Project Structure

